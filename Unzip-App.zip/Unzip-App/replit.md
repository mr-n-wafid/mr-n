# WAFID CARE - Medical Application Portal

## Overview

WAFID CARE is a secure, role-based web platform for managing passport-related medical document submissions for WAFID processing. The system enables users to submit passport documents, select medical centers with dynamic pricing (normal and emergency rates), track submission status, and manage payments. Admins can manage users, pricing, submissions, and communications through a centralized dashboard.

Key features include:
- User authentication with role-based access (admin/user)
- City and medical center management with configurable pricing
- Document submission workflow with file upload or link submission
- Payment tracking with wallet balance system
- Submission status tracking (Pending, Done, DLV_Submitted)
- WhatsApp notification integration for automated communications

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens (CSS variables for theming)
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite with custom plugins for Replit integration

The frontend follows a pages-based architecture with shared components. Protected routes check authentication status and role permissions before rendering.

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Authentication**: Passport.js with local strategy, session-based auth using express-session
- **Password Security**: bcryptjs for password hashing
- **API Design**: RESTful endpoints defined in shared route contracts (`shared/routes.ts`)

The server uses a storage abstraction layer (`IStorage` interface) that decouples business logic from database operations, enabling easier testing and potential database swaps.

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Migrations**: Drizzle Kit for database migrations (`drizzle-kit push`)

Core entities:
- `users` - User accounts with roles, wallet balances, WhatsApp numbers
- `cities` - Geographic locations for medical centers
- `centers` - Medical centers with normal/emergency pricing
- `submissions` - Document submissions linking users to centers
- `payments` - Payment records (schema defined but implementation partial)

### Authentication & Authorization
- Session-based authentication stored server-side
- Two roles: `admin` and `user`
- Admin users have access to user management, submission inbox, and pricing controls
- Regular users can submit documents, view history, and manage payments
- Default admin credentials seeded on startup (username: `adsagor`)

### Shared Code Pattern
The `shared/` directory contains code used by both frontend and backend:
- `schema.ts` - Drizzle table definitions and Zod insert schemas
- `routes.ts` - API route contracts with path, method, and response schemas

This pattern ensures type safety across the full stack and enables runtime validation.

## External Dependencies

### Database
- **PostgreSQL** - Primary database, connection via `DATABASE_URL` environment variable
- **connect-pg-simple** - PostgreSQL session store (available but not currently configured)

### Third-Party Libraries
- **Drizzle ORM** - Type-safe database queries and migrations
- **Passport.js** - Authentication middleware with local strategy
- **bcryptjs** - Password hashing
- **date-fns** - Date formatting utilities
- **Zod** - Runtime schema validation

### UI Component Dependencies
- **Radix UI** - Headless accessible component primitives
- **shadcn/ui** - Pre-styled component library (new-york style variant)
- **Lucide React** - Icon library
- **class-variance-authority** - Component variant management
- **tailwind-merge** - Tailwind class merging utility

### Build & Development
- **Vite** - Frontend build tool and dev server
- **esbuild** - Server bundling for production
- **tsx** - TypeScript execution for development

### Environment Variables Required
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Optional, defaults to hardcoded value (should be set in production)

### WhatsApp Integration (Using Replit Twilio Connector)
The WhatsApp notification feature uses Twilio's WhatsApp Business API via Replit's built-in Twilio connector.

**Setup:**
The Twilio integration is managed through Replit's connector system. Credentials are automatically fetched via `server/twilio.ts` using the Replit Connectors API.

**Features:**
- WhatsApp connection status indicator in Admin Dashboard sidebar (upper left corner)
- Clickable status indicator opens a popover with test message functionality
- "Send Reminder" button in Admin Payments page sends WhatsApp payment reminders to users
- Status auto-refreshes every 60 seconds

**Status Indicator:**
- Green = Connected (Twilio credentials valid)
- Red = Disconnected (credentials missing or connection failed)

**Implementation Files:**
- `server/twilio.ts` - Twilio client initialization and WhatsApp helper functions
- `client/src/components/Layout.tsx` - WhatsApp status indicator UI
- `client/src/hooks/use-gamca.ts` - useWhatsAppStatus and useWhatsAppTest hooks

**File Upload Naming Convention:**
- Uploaded passport files are saved as `username_centername.extension`
- Special characters are removed, spaces replaced with underscores

### Automatic Wallet Deduction System
When a user has a wallet balance and outstanding dues:
- The system automatically applies wallet balance to pay off dues
- This happens when users view their Payment page or when admin views Admin Payments
- Wallet credits are recorded as payment entries with `proofImage="WALLET_CREDIT"` and `status="approved"`
- This ensures proper tracking of all wallet deductions in the payment history
- Due calculation: `totalDue - approvedPayments` (wallet credits are included in approved payments)
- Wallet display in sidebar is only shown to users, not admins

**Implementation Files:**
- `server/routes.ts` - `/api/users/:id/apply-wallet` endpoint
- `client/src/pages/Payment.tsx` - Auto-applies wallet on page load for current user
- `client/src/pages/AdminPayments.tsx` - Auto-applies wallet for all users on page load

### Push Notifications
Browser push notifications are sent to users when their applications are processed.

**Features:**
- Users receive a notification prompt once after login (stored in localStorage)
- When admin marks a submission as "Done", user receives push notification
- Notification message: "Dear Agent, Your [Center Name] slip is Done. Please Check it out."
- Clicking notification opens the History page

**Technical Implementation:**
- Uses Web Push API with VAPID keys for authentication
- Service worker (`client/public/sw.js`) handles push events
- Push subscriptions stored in `pushSubscription` field on users table
- VAPID keys stored in environment variables (VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY)

**Implementation Files:**
- `client/public/sw.js` - Service worker for push notifications
- `server/routes.ts` - Push subscription and notification endpoints
- `client/src/components/Layout.tsx` - Notification permission prompt UI
- `client/src/hooks/use-gamca.ts` - useVapidPublicKey and usePushSubscribe hooks

### Need File Update Notifications
When admin updates the needed quantity for a center (increases it), all users receive a push notification.

**Message Format:**
```
Dear Agent,
We Need '[Center Name]'.
Please Check it out.
```

**Trigger:** When neededQuantity is increased in the Admin "Update Need File" page.

**Implementation:** The PATCH /api/centers/:id endpoint compares previous and new neededQuantity, and broadcasts notification to all non-admin users with push subscriptions using `sendPushNotificationToAll()` helper.