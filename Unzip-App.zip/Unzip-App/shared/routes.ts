import { z } from 'zod';
import { insertUserSchema, insertCitySchema, insertCenterSchema, insertSubmissionSchema, insertPaymentSchema, insertUpdateRequestSchema, users, cities, centers, submissions, payments, updateRequests } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/login',
      input: z.object({
        username: z.string(),
        password: z.string(),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.object({ message: z.string() }),
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/logout',
      responses: {
        200: z.void(),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/user',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.void(),
      },
    },
  },
  cities: {
    list: {
      method: 'GET' as const,
      path: '/api/cities',
      responses: {
        200: z.array(z.custom<typeof cities.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/cities',
      input: insertCitySchema,
      responses: {
        201: z.custom<typeof cities.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  centers: {
    list: {
      method: 'GET' as const,
      path: '/api/centers',
      input: z.object({
        cityId: z.coerce.number().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof centers.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/centers',
      input: insertCenterSchema,
      responses: {
        201: z.custom<typeof centers.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/centers/:id',
      input: z.object({
        name: z.string().optional(),
        cityId: z.number().optional(),
        normalPrice: z.number().optional(),
        emergencyPrice: z.number().optional(),
        neededQuantity: z.number().optional(),
      }),
      responses: {
        200: z.custom<typeof centers.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  submissions: {
    create: {
      method: 'POST' as const,
      path: '/api/submissions',
      input: insertSubmissionSchema,
      responses: {
        201: z.custom<typeof submissions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/submissions',
      responses: {
        200: z.array(z.custom<typeof submissions.$inferSelect & { user: typeof users.$inferSelect, center: typeof centers.$inferSelect, city: typeof cities.$inferSelect }>()),
      },
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/submissions/:id/status',
      input: z.object({ status: z.string() }),
      responses: {
        200: z.custom<typeof submissions.$inferSelect>(),
      },
    },
    // New endpoint for DLV submission
    updateDlv: {
      method: 'POST' as const,
      path: '/api/submissions/:id/dlv',
      input: z.object({
        dlvName: z.string(),
        dlvPassportNumber: z.string(),
        dlvLink: z.string(),
        dlvPrice: z.coerce.number(),
      }),
      responses: {
        200: z.custom<typeof submissions.$inferSelect>(),
      },
    },
  },
  users: {
    create: {
      method: 'POST' as const,
      path: '/api/users',
      input: z.object({
        username: z.string().min(3, "Username must be at least 3 characters"),
        password: z.string().min(6, "Password must be at least 6 characters"),
        whatsappNumber: z.string().regex(/^\+?\d{10,15}$/, "Invalid WhatsApp number format"),
        walletBalance: z.number().min(0).optional().default(0),
        role: z.enum(["user", "admin"]).optional().default("user"),
      }),
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
        409: z.object({ message: z.string() }),
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
    listWithStats: {
      method: 'GET' as const,
      path: '/api/users/stats',
      responses: {
        200: z.array(z.object({
          id: z.number(),
          username: z.string(),
          whatsappNumber: z.string().nullable(),
          walletBalance: z.number(),
          role: z.string(),
          createdAt: z.string().nullable(),
          totalSubmissions: z.number(),
          completedSubmissions: z.number(),
          pendingSubmissions: z.number(),
        })),
      },
    },
    updateWallet: {
      method: 'PATCH' as const,
      path: '/api/users/:id/wallet',
      input: z.object({ amount: z.number() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/users/:id',
      responses: {
        200: z.object({ success: z.boolean() }),
        404: z.object({ message: z.string() }),
      },
    },
    applyWalletToDues: {
      method: 'POST' as const,
      path: '/api/users/:id/apply-wallet',
      responses: {
        200: z.object({
          walletApplied: z.number(),
          newWalletBalance: z.number(),
          remainingDue: z.number(),
        }),
        404: z.object({ message: z.string() }),
      },
    },
  },
  payments: {
    create: {
      method: 'POST' as const,
      path: '/api/payments',
      input: z.object({
        amount: z.number(),
        paymentProof: z.string(),
      }),
      responses: {
        201: z.custom<typeof payments.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/payments',
      responses: {
        200: z.array(z.custom<typeof payments.$inferSelect & { user: typeof users.$inferSelect }>()),
      },
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/payments/:id/status',
      input: z.object({ status: z.enum(["pending", "approved", "rejected"]) }),
      responses: {
        200: z.custom<typeof payments.$inferSelect>(),
      },
    },
  },
  updateRequests: {
    create: {
      method: 'POST' as const,
      path: '/api/update-requests',
      input: z.object({
        userId: z.number(),
        submissionId: z.number().optional(),
        requestType: z.string(),
        description: z.string(),
      }),
      responses: {
        201: z.custom<typeof updateRequests.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/update-requests',
      responses: {
        200: z.array(z.custom<typeof updateRequests.$inferSelect & { user: typeof users.$inferSelect }>()),
      },
    },
    respond: {
      method: 'PATCH' as const,
      path: '/api/update-requests/:id/respond',
      input: z.object({ responseFile: z.string() }),
      responses: {
        200: z.custom<typeof updateRequests.$inferSelect>(),
      },
    },
    complete: {
      method: 'PATCH' as const,
      path: '/api/update-requests/:id/complete',
      responses: {
        200: z.custom<typeof updateRequests.$inferSelect>(),
      },
    },
  },
  whatsapp: {
    status: {
      method: 'GET' as const,
      path: '/api/whatsapp/status',
      responses: {
        200: z.object({ 
          connected: z.boolean(), 
          phoneNumber: z.string().optional(),
          error: z.string().optional()
        }),
      },
    },
    test: {
      method: 'POST' as const,
      path: '/api/whatsapp/test',
      input: z.object({
        testNumber: z.string().regex(/^\+?\d{10,15}$/, "Invalid phone number format")
      }),
      responses: {
        200: z.object({
          success: z.boolean(),
          message: z.string(),
          sid: z.string().optional()
        }),
      },
    },
  },
  notifications: {
    sendPaymentReminder: {
      method: 'POST' as const,
      path: '/api/notifications/payment-reminder',
      input: z.object({
        userId: z.number(),
        totalDue: z.number(),
      }),
      responses: {
        200: z.object({ success: z.boolean(), message: z.string().optional() }),
      },
    },
  },
  push: {
    subscribe: {
      method: 'POST' as const,
      path: '/api/push/subscribe',
      input: z.object({
        subscription: z.string(),
      }),
      responses: {
        200: z.object({ success: z.boolean() }),
      },
    },
    vapidPublicKey: {
      method: 'GET' as const,
      path: '/api/push/vapid-public-key',
      responses: {
        200: z.object({ publicKey: z.string() }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
