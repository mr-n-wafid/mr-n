import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  whatsappNumber: text("whatsapp_number"),
  walletBalance: integer("wallet_balance").notNull().default(0),
  pushSubscription: text("push_subscription"), // JSON string of push subscription
  role: text("role").notNull().default("user"), // "admin" or "user"
  createdAt: timestamp("created_at").defaultNow(),
});

export const cities = pgTable("cities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const centers = pgTable("centers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  cityId: integer("city_id").notNull().references(() => cities.id),
  normalPrice: integer("normal_price").notNull(),
  emergencyPrice: integer("emergency_price").notNull(),
  neededQuantity: integer("needed_quantity").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const submissions = pgTable("submissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  cityId: integer("city_id").notNull().references(() => cities.id),
  centerId: integer("center_id").notNull().references(() => centers.id),
  deliveryType: text("delivery_type").notNull(), // "none" (Normal) or "emergency"
  passportFile: text("passport_file"), // Store file path or base64
  passportLink: text("passport_link"),
  appliedPrice: integer("applied_price").notNull(),
  status: text("status").notNull().default("Pending"), // Pending, Done, DLV_Submitted, Rejected
  
  // DLV Fields
  dlvName: text("dlv_name"),
  dlvPassportNumber: text("dlv_passport_number"),
  dlvLink: text("dlv_link"),
  dlvPrice: integer("dlv_price"),

  createdAt: timestamp("created_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: integer("amount").notNull(),
  paymentProof: text("payment_proof"),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  createdAt: timestamp("created_at").defaultNow(),
});

export const updateRequests = pgTable("update_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  submissionId: integer("submission_id").references(() => submissions.id),
  requestType: text("request_type").notNull(), // "passport", "document", "other"
  description: text("description").notNull(),
  responseFile: text("response_file"), // User's uploaded file in response
  status: text("status").notNull().default("pending"), // pending, completed
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  submissions: many(submissions),
  payments: many(payments),
}));

export const citiesRelations = relations(cities, ({ many }) => ({
  centers: many(centers),
}));

export const centersRelations = relations(centers, ({ one }) => ({
  city: one(cities, {
    fields: [centers.cityId],
    references: [cities.id],
  }),
}));

export const submissionsRelations = relations(submissions, ({ one }) => ({
  user: one(users, {
    fields: [submissions.userId],
    references: [users.id],
  }),
  city: one(cities, {
    fields: [submissions.cityId],
    references: [cities.id],
  }),
  center: one(centers, {
    fields: [submissions.centerId],
    references: [centers.id],
  }),
}));

// Relations for update requests
export const updateRequestsRelations = relations(updateRequests, ({ one }) => ({
  user: one(users, {
    fields: [updateRequests.userId],
    references: [users.id],
  }),
  submission: one(submissions, {
    fields: [updateRequests.submissionId],
    references: [submissions.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, {
    fields: [payments.userId],
    references: [users.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertCitySchema = createInsertSchema(cities).omit({ id: true });
export const insertCenterSchema = createInsertSchema(centers).omit({ id: true, createdAt: true });
export const insertSubmissionSchema = createInsertSchema(submissions).omit({ 
  id: true, 
  userId: true, // Injected by backend
  createdAt: true, 
  status: true,
  dlvName: true,
  dlvPassportNumber: true,
  dlvLink: true,
  dlvPrice: true
});
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true, userId: true, createdAt: true, status: true });
export const insertUpdateRequestSchema = createInsertSchema(updateRequests).omit({ id: true, createdAt: true, responseFile: true, status: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type City = typeof cities.$inferSelect;
export type Center = typeof centers.$inferSelect;
export type Submission = typeof submissions.$inferSelect;
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type UpdateRequest = typeof updateRequests.$inferSelect;
export type InsertUpdateRequest = z.infer<typeof insertUpdateRequestSchema>;
