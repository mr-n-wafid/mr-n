import { users, cities, centers, submissions, payments, updateRequests, type User, type InsertUser, type City, type InsertCity, type Center, type InsertCenter, type Submission, type InsertSubmission, type Payment, type InsertPayment, type UpdateRequest, type InsertUpdateRequest } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;

  getCities(): Promise<City[]>;
  createCity(city: InsertCity): Promise<City>;

  getCenters(cityId?: number): Promise<Center[]>;
  getCenter(id: number): Promise<Center | undefined>;
  createCenter(center: InsertCenter): Promise<Center>;

  createSubmission(submission: InsertSubmission): Promise<Submission>;
  getSubmissions(): Promise<(Submission & { user: User, center: Center, city: City })[]>;
  getSubmissionById(id: number): Promise<Submission | undefined>;
  updateSubmissionStatus(id: number, status: string): Promise<Submission | undefined>;
  updateSubmissionDlv(id: number, dlvData: Partial<Submission>): Promise<Submission | undefined>;
  updateUserWallet(id: number, amount: number): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  updateCenter(id: number, data: Partial<Center>): Promise<Center | undefined>;

  // Payments
  createPayment(payment: InsertPayment & { userId: number }): Promise<Payment>;
  getPayments(): Promise<(Payment & { user: User })[]>;
  updatePaymentStatus(id: number, status: string): Promise<Payment | undefined>;

  // Update Requests
  createUpdateRequest(request: InsertUpdateRequest): Promise<UpdateRequest>;
  getUpdateRequests(): Promise<(UpdateRequest & { user: User })[]>;
  getUpdateRequestsByUser(userId: number): Promise<UpdateRequest[]>;
  respondToUpdateRequest(id: number, responseFile: string): Promise<UpdateRequest | undefined>;
  completeUpdateRequest(id: number): Promise<UpdateRequest | undefined>;

  // Push Notifications
  updatePushSubscription(userId: number, subscription: string | null): Promise<User | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserWallet(id: number, amount: number): Promise<User | undefined> {
    const [user] = await db.update(users)
      .set({ walletBalance: amount })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async deleteUser(id: number): Promise<boolean> {
    // First delete related submissions
    await db.delete(submissions).where(eq(submissions.userId, id));
    // Then delete related payments
    await db.delete(payments).where(eq(payments.userId, id));
    // Finally delete the user
    const result = await db.delete(users).where(eq(users.id, id)).returning();
    return result.length > 0;
  }

  async getCities(): Promise<City[]> {
    return await db.select().from(cities);
  }

  async createCity(insertCity: InsertCity): Promise<City> {
    const [city] = await db.insert(cities).values(insertCity).returning();
    return city;
  }

  async getCenters(cityId?: number): Promise<Center[]> {
    if (cityId) {
      return await db.select().from(centers).where(eq(centers.cityId, cityId));
    }
    return await db.select().from(centers);
  }

  async getCenter(id: number): Promise<Center | undefined> {
    const [center] = await db.select().from(centers).where(eq(centers.id, id));
    return center;
  }

  async createCenter(insertCenter: InsertCenter): Promise<Center> {
    const [center] = await db.insert(centers).values(insertCenter).returning();
    return center;
  }

  async updateCenter(id: number, data: Partial<Center>): Promise<Center | undefined> {
    const [center] = await db.update(centers)
      .set(data)
      .where(eq(centers.id, id))
      .returning();
    return center;
  }

  async createSubmission(insertSubmission: InsertSubmission): Promise<Submission> {
    const [submission] = await db.insert(submissions).values(insertSubmission).returning();
    return submission;
  }

  async getSubmissions(): Promise<(Submission & { user: User, center: Center, city: City })[]> {
    const results = await db.query.submissions.findMany({
      with: {
        user: true,
        city: true,
        center: true,
      },
    });
    return results;
  }

  async getSubmissionById(id: number): Promise<Submission | undefined> {
    const [submission] = await db.select().from(submissions).where(eq(submissions.id, id));
    return submission;
  }

  async updateSubmissionStatus(id: number, status: string): Promise<Submission | undefined> {
    const [submission] = await db.update(submissions)
      .set({ status })
      .where(eq(submissions.id, id))
      .returning();
    return submission;
  }

  async updateSubmissionDlv(id: number, dlvData: Partial<Submission>): Promise<Submission | undefined> {
    const [submission] = await db.update(submissions)
      .set({ ...dlvData, status: 'DLV_Submitted' })
      .where(eq(submissions.id, id))
      .returning();
    return submission;
  }

  // Payments
  async createPayment(payment: InsertPayment & { userId: number }): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async getPayments(): Promise<(Payment & { user: User })[]> {
    const results = await db.query.payments.findMany({
      with: {
        user: true,
      },
      orderBy: (payments, { desc }) => [desc(payments.createdAt)],
    });
    return results;
  }

  async updatePaymentStatus(id: number, status: string): Promise<Payment | undefined> {
    const [payment] = await db.update(payments)
      .set({ status })
      .where(eq(payments.id, id))
      .returning();
    return payment;
  }

  // Update Requests
  async createUpdateRequest(request: InsertUpdateRequest): Promise<UpdateRequest> {
    const [newRequest] = await db.insert(updateRequests).values(request).returning();
    return newRequest;
  }

  async getUpdateRequests(): Promise<(UpdateRequest & { user: User })[]> {
    const results = await db.query.updateRequests.findMany({
      with: {
        user: true,
      },
      orderBy: (updateRequests, { desc }) => [desc(updateRequests.createdAt)],
    });
    return results;
  }

  async getUpdateRequestsByUser(userId: number): Promise<UpdateRequest[]> {
    return await db.select().from(updateRequests).where(eq(updateRequests.userId, userId));
  }

  async respondToUpdateRequest(id: number, responseFile: string): Promise<UpdateRequest | undefined> {
    const [request] = await db.update(updateRequests)
      .set({ responseFile, status: 'completed' })
      .where(eq(updateRequests.id, id))
      .returning();
    return request;
  }

  async completeUpdateRequest(id: number): Promise<UpdateRequest | undefined> {
    const [request] = await db.update(updateRequests)
      .set({ status: 'completed' })
      .where(eq(updateRequests.id, id))
      .returning();
    return request;
  }

  async updatePushSubscription(userId: number, subscription: string | null): Promise<User | undefined> {
    const [user] = await db.update(users)
      .set({ pushSubscription: subscription })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
}

export const storage = new DatabaseStorage();
