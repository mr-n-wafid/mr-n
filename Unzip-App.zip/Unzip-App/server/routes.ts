import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { api } from "@shared/routes";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { sendWhatsAppMessage, checkTwilioConnection } from "./twilio";
import webpush from "web-push";

// Configure web-push with VAPID keys
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || "";
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || "";

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(
    "mailto:admin@wafidcare.com",
    VAPID_PUBLIC_KEY,
    VAPID_PRIVATE_KEY
  );
}

// Helper function to send push notification
async function sendPushNotification(userId: number, title: string, body: string, url: string = "/history") {
  try {
    const user = await storage.getUser(userId);
    if (!user?.pushSubscription) {
      return { success: false, error: "No push subscription found" };
    }

    const subscription = JSON.parse(user.pushSubscription);
    const payload = JSON.stringify({ title, body, url });

    await webpush.sendNotification(subscription, payload);
    return { success: true };
  } catch (error: any) {
    console.error("Push notification error:", error);
    // If subscription is invalid, remove it
    if (error.statusCode === 410 || error.statusCode === 404) {
      await storage.updatePushSubscription(userId, null);
    }
    return { success: false, error: error.message };
  }
}

// Helper function to send push notification to all users
async function sendPushNotificationToAll(title: string, body: string, url: string = "/need-file") {
  try {
    const allUsers = await storage.getUsers();
    const usersWithSubscription = allUsers.filter(u => u.pushSubscription && u.role !== 'admin');
    
    const results = await Promise.allSettled(
      usersWithSubscription.map(async (user) => {
        try {
          const subscription = JSON.parse(user.pushSubscription!);
          const payload = JSON.stringify({ title, body, url });
          await webpush.sendNotification(subscription, payload);
          return { userId: user.id, success: true };
        } catch (error: any) {
          if (error.statusCode === 410 || error.statusCode === 404) {
            await storage.updatePushSubscription(user.id, null);
          }
          return { userId: user.id, success: false, error: error.message };
        }
      })
    );
    
    const successCount = results.filter(r => r.status === 'fulfilled' && (r.value as any).success).length;
    return { success: true, sent: successCount, total: usersWithSubscription.length };
  } catch (error: any) {
    console.error("Broadcast push notification error:", error);
    return { success: false, error: error.message };
  }
}

async function seedAdmin() {
  const adminUsername = "adsagor";
  const adminPassword = "sagor8009admin";
  
  const existingUser = await storage.getUserByUsername(adminUsername);
  if (!existingUser) {
    const hashedPassword = await bcrypt.hash(adminPassword, 10);
    await storage.createUser({
      username: adminUsername,
      password: hashedPassword,
      role: "admin",
      whatsappNumber: "0000000000"
    });
    console.log("Admin user created");
  } else {
    console.log("Admin user already exists");
  }

  // Seed some cities and centers if empty
  const cities = await storage.getCities();
  if (cities.length === 0) {
    const dhaka = await storage.createCity({ name: "Dhaka" });
    const chittagong = await storage.createCity({ name: "Chittagong" });

    await storage.createCenter({ name: "Ibn Sina Medical", cityId: dhaka.id, normalPrice: 5000, emergencyPrice: 8000 });
    await storage.createCenter({ name: "Popular Diagnostic", cityId: dhaka.id, normalPrice: 5500, emergencyPrice: 8500 });
    await storage.createCenter({ name: "Chevron", cityId: chittagong.id, normalPrice: 4500, emergencyPrice: 7000 });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupAuth(app);

  // Admin Seed
  await seedAdmin();

  // Cities
  app.get(api.cities.list.path, async (req, res) => {
    const cities = await storage.getCities();
    res.json(cities);
  });

  // Centers
  app.get(api.centers.list.path, async (req, res) => {
    const cityId = req.query.cityId ? Number(req.query.cityId) : undefined;
    const centers = await storage.getCenters(cityId);
    res.json(centers);
  });

  app.post(api.centers.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const input = api.centers.create.input.parse(req.body);
    const center = await storage.createCenter(input);
    res.status(201).json(center);
  });

  app.patch(api.centers.update.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const id = Number(req.params.id);
    
    // Get current center to check if neededQuantity changed
    const currentCenter = await storage.getCenter(id);
    if (!currentCenter) return res.status(404).send("Not found");
    
    const previousQuantity = currentCenter.neededQuantity || 0;
    const input = api.centers.update.input.parse(req.body);
    
    const updated = await storage.updateCenter(id, input);
    if (!updated) return res.status(404).send("Not found");
    
    // Send push notification to all users if neededQuantity increased
    if (updated.neededQuantity !== undefined && updated.neededQuantity > previousQuantity) {
      sendPushNotificationToAll(
        "Need File Update",
        `Dear Agent,\nWe Need '${updated.name}'.\nPlease Check it out.`,
        "/need-file"
      ).catch(err => console.error("Failed to send need file notification:", err));
    }
    
    res.json(updated);
  });

  // Cities
  app.get(api.cities.list.path, async (req, res) => {
    const cities = await storage.getCities();
    res.json(cities);
  });

  app.post(api.cities.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const input = api.cities.create.input.parse(req.body);
    const city = await storage.createCity(input);
    res.status(201).json(city);
  });

  // Submissions
  app.post(api.submissions.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const input = api.submissions.create.input.parse(req.body);
    
    // Deduct from wallet if user has enough balance
    if (req.user!.walletBalance < input.appliedPrice) {
       // Allow for now but track due? User asked for minus from due.
    }

    const submission = await storage.createSubmission({
      ...input,
      userId: req.user!.id,
    });
    res.status(201).json(submission);
  });

  app.get(api.submissions.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const allSubmissions = await storage.getSubmissions();
    
    if (req.user!.role === 'admin') {
      res.json(allSubmissions);
    } else {
      // Filter for user
      res.json(allSubmissions.filter(s => s.userId === req.user!.id));
    }
  });

  app.patch(api.submissions.updateStatus.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const { status } = req.body;
    const id = Number(req.params.id);
    
    // Get submission details before update for notification
    const allSubmissions = await storage.getSubmissions();
    const submissionDetails = allSubmissions.find(s => s.id === id);
    
    const updated = await storage.updateSubmissionStatus(id, status);
    if (!updated) return res.status(404).send("Not found");
    
    // Send push notification when status changes to "Done"
    if (status === 'Done' && submissionDetails) {
      const centerName = submissionDetails.center?.name || "your selected center";
      await sendPushNotification(
        submissionDetails.userId,
        "WAFID CARE",
        `Dear Agent,\nYour ${centerName} slip is Done.\nPlease Check it out.`,
        "/history"
      );
    }
    
    res.json(updated);
  });

  app.post(api.submissions.updateDlv.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const input = api.submissions.updateDlv.input.parse(req.body);
    const id = Number(req.params.id);
    const updated = await storage.updateSubmissionDlv(id, input);
    
    if (!updated) return res.status(404).send("Not found");

    res.json(updated);
  });

  // Users
  app.post(api.users.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    try {
      const input = api.users.create.input.parse(req.body);
      
      // Check for duplicate username
      const existingUser = await storage.getUserByUsername(input.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const hashedPassword = await bcrypt.hash(input.password, 10);
      const user = await storage.createUser({ ...input, password: hashedPassword });
      res.status(201).json(user);
    } catch (err: any) {
      if (err.name === 'ZodError') {
        return res.status(400).json({ message: err.errors[0]?.message || "Validation error" });
      }
      throw err;
    }
  });
  
  // Users with submission stats - MUST be before /api/users to match first
  app.get(api.users.listWithStats.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const users = await storage.getUsers();
    const allSubmissions = await storage.getSubmissions();
    
    const usersWithStats = users.map(user => {
      const userSubmissions = allSubmissions.filter(s => s.userId === user.id);
      const completed = userSubmissions.filter(s => s.status === 'Done' || s.status === 'DLV_Submitted').length;
      const pending = userSubmissions.filter(s => s.status === 'Pending').length;
      
      return {
        id: user.id,
        username: user.username,
        whatsappNumber: user.whatsappNumber,
        walletBalance: user.walletBalance,
        role: user.role,
        createdAt: user.createdAt ? user.createdAt.toISOString() : null,
        totalSubmissions: userSubmissions.length,
        completedSubmissions: completed,
        pendingSubmissions: pending,
      };
    });
    
    res.json(usersWithStats);
  });

  app.get(api.users.list.path, async (req, res) => {
     if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const users = await storage.getUsers();
    res.json(users);
  });

  app.patch(api.users.updateWallet.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const id = Number(req.params.id);
    const { amount } = req.body;
    
    // Validate amount is a finite number >= 0
    if (!Number.isFinite(amount) || amount < 0) {
      return res.status(400).json({ message: "Invalid wallet amount" });
    }
    
    const updated = await storage.updateUserWallet(id, Math.floor(amount));
    if (!updated) return res.status(404).send("Not found");
    res.json(updated);
  });

  // Delete user
  app.delete(api.users.delete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const id = Number(req.params.id);
    // Prevent deleting the currently logged-in user
    if (id === req.user!.id) {
      return res.status(400).json({ message: "Cannot delete your own account" });
    }
    const deleted = await storage.deleteUser(id);
    if (!deleted) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json({ success: true });
  });

  // Apply Wallet to Dues - automatically deduct wallet balance from outstanding dues
  // Creates a "wallet_credit" payment record to track the deduction
  app.post(api.users.applyWalletToDues.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const id = Number(req.params.id);
    
    // Users can only apply their own wallet, admins can apply for any user
    if (req.user!.role !== 'admin' && req.user!.id !== id) {
      return res.status(403).send("Unauthorized");
    }
    
    const user = await storage.getUser(id);
    if (!user) return res.status(404).json({ message: "User not found" });
    
    // Calculate total dues (only Done and DLV_Submitted submissions)
    const allSubmissions = await storage.getSubmissions();
    const userSubmissions = allSubmissions.filter(s => s.userId === id && (s.status === 'Done' || s.status === 'DLV_Submitted'));
    const totalDue = userSubmissions.reduce((sum, s) => sum + s.appliedPrice + (s.dlvPrice || 0), 0);
    
    // Get approved payments (including wallet credits)
    const allPayments = await storage.getPayments();
    const approvedPayments = allPayments
      .filter(p => p.userId === id && p.status === 'approved')
      .reduce((sum, p) => sum + p.amount, 0);
    
    // Calculate outstanding due
    const outstandingDue = Math.max(0, totalDue - approvedPayments);
    
    // Calculate how much wallet to apply
    const walletBalance = user.walletBalance || 0;
    const walletToApply = Math.min(walletBalance, outstandingDue);
    
    // Deduct from wallet and create payment record if there's an amount to apply
    let newWalletBalance = walletBalance;
    if (walletToApply > 0) {
      newWalletBalance = walletBalance - walletToApply;
      await storage.updateUserWallet(id, newWalletBalance);
      
      // Create an auto-approved payment record for the wallet credit
      await storage.createPayment({
        userId: id,
        amount: walletToApply,
        proofImage: "WALLET_CREDIT",
        status: "approved",
      });
    }
    
    const remainingDue = outstandingDue - walletToApply;
    
    res.json({
      walletApplied: walletToApply,
      newWalletBalance,
      remainingDue,
    });
  });

  // File Download Endpoint
  app.get("/api/submissions/:id/download", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const id = Number(req.params.id);
    const submission = await storage.getSubmissionById(id);
    
    if (!submission || !submission.passportFile) {
      return res.status(404).send("File not found");
    }
    
    const parts = submission.passportFile.split("::");
    if (parts.length < 2) {
      return res.status(404).send("File data not available");
    }
    
    const fileName = parts[0];
    const base64Data = parts.slice(1).join("::");
    
    const matches = base64Data.match(/^data:(.+);base64,(.+)$/);
    if (!matches) {
      return res.status(400).send("Invalid file format");
    }
    
    const mimeType = matches[1];
    const fileBuffer = Buffer.from(matches[2], 'base64');
    
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Length', fileBuffer.length);
    res.send(fileBuffer);
  });

  // Payments
  app.post(api.payments.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const input = api.payments.create.input.parse(req.body);
    const payment = await storage.createPayment({
      ...input,
      userId: req.user!.id,
    });
    res.status(201).json(payment);
  });

  app.get(api.payments.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const allPayments = await storage.getPayments();
    
    if (req.user!.role === 'admin') {
      res.json(allPayments);
    } else {
      res.json(allPayments.filter(p => p.userId === req.user!.id));
    }
  });

  app.patch(api.payments.updateStatus.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const id = Number(req.params.id);
    const { status } = req.body;
    const updated = await storage.updatePaymentStatus(id, status);
    if (!updated) return res.status(404).send("Not found");
    res.json(updated);
  });

  // Update Requests
  app.post(api.updateRequests.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const input = api.updateRequests.create.input.parse(req.body);
    const request = await storage.createUpdateRequest(input);
    res.status(201).json(request);
  });

  app.get(api.updateRequests.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    if (req.user!.role === 'admin') {
      const allRequests = await storage.getUpdateRequests();
      res.json(allRequests);
    } else {
      const userRequests = await storage.getUpdateRequestsByUser(req.user!.id);
      res.json(userRequests);
    }
  });

  app.patch(api.updateRequests.respond.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const id = Number(req.params.id);
    const { responseFile } = req.body;
    const updated = await storage.respondToUpdateRequest(id, responseFile);
    if (!updated) return res.status(404).send("Not found");
    res.json(updated);
  });

  app.patch(api.updateRequests.complete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const id = Number(req.params.id);
    const updated = await storage.completeUpdateRequest(id);
    if (!updated) return res.status(404).send("Not found");
    res.json(updated);
  });

  // File Download for Payments
  app.get("/api/payments/:id/download", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const id = Number(req.params.id);
    const allPayments = await storage.getPayments();
    const payment = allPayments.find(p => p.id === id);
    
    if (!payment || !payment.paymentProof) {
      return res.status(404).send("File not found");
    }
    
    const parts = payment.paymentProof.split("::");
    if (parts.length < 2) {
      return res.status(404).send("File data not available");
    }
    
    const fileName = parts[0];
    const base64Data = parts.slice(1).join("::");
    
    const matches = base64Data.match(/^data:(.+);base64,(.+)$/);
    if (!matches) {
      return res.status(400).send("Invalid file format");
    }
    
    const mimeType = matches[1];
    const fileBuffer = Buffer.from(matches[2], 'base64');
    
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Length', fileBuffer.length);
    res.send(fileBuffer);
  });

  // File Download for Update Request Responses
  app.get("/api/update-requests/:id/download", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const id = Number(req.params.id);
    const allRequests = await storage.getUpdateRequests();
    const request = allRequests.find(r => r.id === id);
    
    if (!request || !request.responseFile) {
      return res.status(404).send("File not found");
    }
    
    const parts = request.responseFile.split("::");
    if (parts.length < 2) {
      return res.status(404).send("File data not available");
    }
    
    const fileName = parts[0];
    const base64Data = parts.slice(1).join("::");
    
    const matches = base64Data.match(/^data:(.+);base64,(.+)$/);
    if (!matches) {
      return res.status(400).send("Invalid file format");
    }
    
    const mimeType = matches[1];
    const fileBuffer = Buffer.from(matches[2], 'base64');
    
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Length', fileBuffer.length);
    res.send(fileBuffer);
  });

  // WhatsApp Status
  app.get(api.whatsapp.status.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    
    const status = await checkTwilioConnection();
    res.json(status);
  });
  
  // WhatsApp Test Message
  app.post(api.whatsapp.test.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    
    const input = api.whatsapp.test.input.parse(req.body);
    const result = await sendWhatsAppMessage(
      input.testNumber,
      `WAFID CARE - WhatsApp Test\n\nThis is a test message to verify WhatsApp integration is working correctly.\n\nTime: ${new Date().toISOString()}`
    );
    
    if (result.success) {
      res.json({ success: true, message: "Test message sent successfully", sid: result.sid });
    } else {
      res.json({ success: false, message: result.error || "Failed to send message" });
    }
  });

  // Payment Reminder
  app.post(api.notifications.sendPaymentReminder.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') {
      return res.status(403).send("Unauthorized");
    }
    const { userId, totalDue } = req.body;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    
    if (!user.whatsappNumber) {
      return res.json({ success: false, message: "User has no WhatsApp number" });
    }
    
    const result = await sendWhatsAppMessage(
      user.whatsappNumber,
      `WAFID CARE Payment Reminder\n\nDear ${user.username},\n\nYour total due amount is ${totalDue.toLocaleString()} BDT.\n\nPlease make the payment at your earliest convenience.\n\nThank you!`
    );
    
    if (result.success) {
      res.json({ success: true, message: "Reminder sent successfully" });
    } else {
      res.json({ success: false, message: result.error || "Failed to send reminder" });
    }
  });

  // Push Notification - Subscribe
  app.post(api.push.subscribe.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send("Unauthorized");
    
    const input = api.push.subscribe.input.parse(req.body);
    await storage.updatePushSubscription(req.user!.id, input.subscription);
    res.json({ success: true });
  });

  // Push Notification - Get VAPID Public Key
  app.get(api.push.vapidPublicKey.path, (req, res) => {
    res.json({ publicKey: VAPID_PUBLIC_KEY });
  });

  return httpServer;
}
