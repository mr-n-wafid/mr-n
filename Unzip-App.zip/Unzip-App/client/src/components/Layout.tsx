import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  History, 
  DollarSign, 
  Building2, 
  LogOut, 
  Menu, 
  Users, 
  ShieldCheck,
  FileText,
  FolderUp,
  Bell,
  X
} from "lucide-react";
import { useState, useEffect } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useVapidPublicKey, usePushSubscribe } from "@/hooks/use-gamca";
import { Card, CardContent } from "@/components/ui/card";


// Helper to convert VAPID key to Uint8Array
function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const [showNotificationPrompt, setShowNotificationPrompt] = useState(false);
  const { data: vapidData } = useVapidPublicKey();
  const pushSubscribe = usePushSubscribe();
  
  const isAdmin = user?.role === "admin";

  // Check if we should show notification prompt (only for non-admin users, once)
  useEffect(() => {
    if (!user || isAdmin) return;
    
    const hasAskedBefore = localStorage.getItem('notificationPromptShown');
    const notificationPermission = Notification?.permission;
    
    // Show prompt if: not asked before, notifications supported, and not already granted/denied
    if (!hasAskedBefore && 'Notification' in window && notificationPermission === 'default') {
      // Small delay to let page load first
      const timer = setTimeout(() => setShowNotificationPrompt(true), 2000);
      return () => clearTimeout(timer);
    }
  }, [user, isAdmin]);

  const handleEnableNotifications = async () => {
    try {
      localStorage.setItem('notificationPromptShown', 'true');
      
      // Check if service workers are supported
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        console.warn('Push notifications not supported in this browser');
        setShowNotificationPrompt(false);
        return;
      }
      
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        setShowNotificationPrompt(false);
        return;
      }

      // Register service worker
      const registration = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;

      // Subscribe to push
      if (vapidData?.publicKey) {
        const subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(vapidData.publicKey),
        });

        // Send subscription to server
        await pushSubscribe.mutateAsync(JSON.stringify(subscription));
      }
      
      setShowNotificationPrompt(false);
    } catch (error) {
      console.error('Error enabling notifications:', error);
      setShowNotificationPrompt(false);
    }
  };

  const handleDismissNotifications = () => {
    localStorage.setItem('notificationPromptShown', 'true');
    setShowNotificationPrompt(false);
  };

  const userLinks = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/history", label: "History", icon: History },
    { href: "/pricing", label: "Centers Rate", icon: Building2 },
    { href: "/need-file", label: "Need File", icon: FileText },
    { href: "/payment", label: "Payment", icon: DollarSign },
  ];

  const adminLinks = [
    { href: "/admin", label: "Admin Dashboard", icon: ShieldCheck },
    { href: "/admin/users", label: "Wallet Control", icon: Users },
    { href: "/pricing", label: "Centers & Rates", icon: Building2 },
    { href: "/admin/need-file", label: "Update Need File", icon: FolderUp },
    { href: "/admin/payments", label: "Admin Payment", icon: DollarSign },
  ];

  const links = isAdmin ? adminLinks : userLinks;

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-slate-900 text-white">
      <div className="p-6 flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold font-display tracking-tight text-blue-400">
            WAFID<span className="text-white">CARE</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">Medical Application Portal</p>
        </div>
        {!isAdmin && (
          <div className="bg-blue-500/20 px-3 py-1 rounded-full border border-blue-500/30">
            <p className="text-[10px] text-blue-400 font-bold uppercase">Wallet</p>
            <p className={`font-bold text-white ${
              (user?.walletBalance || 0) >= 100000 ? 'text-xs' : 
              (user?.walletBalance || 0) >= 10000 ? 'text-sm' : 'text-base'
            }`}>
              {(user?.walletBalance || 0).toLocaleString()} BDT
            </p>
          </div>
        )}
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location === link.href;
          return (
            <Link key={link.href} href={link.href} className={`
              flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200
              ${isActive 
                ? "bg-primary text-white shadow-lg shadow-primary/25" 
                : "text-slate-400 hover:text-white hover:bg-white/10"
              }
            `} onClick={() => setOpen(false)}>
              <Icon className="w-5 h-5" />
              <span className="font-medium">{link.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 mt-auto border-t border-white/10">
        <div className="flex items-center gap-3 px-4 py-3 mb-2">
          <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 font-bold">
            {user?.username.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium truncate">{user?.username}</p>
            <p className="text-xs text-slate-400 capitalize">{user?.role}</p>
          </div>
        </div>
        <button
          onClick={() => logoutMutation.mutate()}
          className="flex items-center gap-3 px-4 py-2 w-full rounded-lg text-red-400 hover:bg-red-500/10 transition-colors text-sm font-medium"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-72 fixed inset-y-0 z-50 shadow-xl">
        <SidebarContent />
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-slate-900 z-40 flex items-center justify-between px-4 shadow-md">
        <span className="text-xl font-bold font-display text-white">WAFID<span className="text-blue-400">CARE</span></span>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 border-r-slate-800 w-72 bg-slate-900">
            <SidebarContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:pl-72 pt-16 lg:pt-0 min-h-screen transition-all duration-300">
        <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {children}
        </div>
      </main>

      {/* Notification Permission Prompt */}
      {showNotificationPrompt && (
        <div className="fixed bottom-4 right-4 z-50 animate-in slide-in-from-bottom-4 duration-300" data-testid="notification-prompt">
          <Card className="w-80 shadow-lg border-blue-200 bg-white">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-full bg-blue-100 text-blue-600">
                  <Bell className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">Enable Notifications</h4>
                  <p className="text-xs text-gray-600 mb-3">
                    Get notified when your applications are processed.
                  </p>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      onClick={handleEnableNotifications}
                      disabled={pushSubscribe.isPending}
                      data-testid="button-enable-notifications"
                    >
                      {pushSubscribe.isPending ? "Enabling..." : "Enable"}
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={handleDismissNotifications}
                      data-testid="button-dismiss-notifications"
                    >
                      Not Now
                    </Button>
                  </div>
                </div>
                <button 
                  onClick={handleDismissNotifications}
                  className="text-gray-400 hover:text-gray-600"
                  data-testid="button-close-notification-prompt"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
