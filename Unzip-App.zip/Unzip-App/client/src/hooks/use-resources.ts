import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

// ==========================================
// CITIES & CENTERS
// ==========================================

export function useCities() {
  return useQuery({
    queryKey: [api.cities.list.path],
    queryFn: async () => {
      const res = await fetch(api.cities.list.path);
      if (!res.ok) throw new Error("Failed to fetch cities");
      return api.cities.list.responses[200].parse(await res.json());
    },
  });
}

export function useCenters(cityId?: number) {
  return useQuery({
    queryKey: [api.centers.list.path, cityId],
    queryFn: async () => {
      const url = cityId 
        ? `${api.centers.list.path}?cityId=${cityId}`
        : api.centers.list.path;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch centers");
      return api.centers.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateCenter() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch(api.centers.create.path, {
        method: api.centers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create center");
      return api.centers.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.centers.list.path] });
      toast({ title: "Success", description: "Center created successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

// ==========================================
// SUBMISSIONS
// ==========================================

export function useSubmissions() {
  return useQuery({
    queryKey: [api.submissions.list.path],
    queryFn: async () => {
      const res = await fetch(api.submissions.list.path);
      if (!res.ok) throw new Error("Failed to fetch submissions");
      return api.submissions.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateSubmission() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch(api.submissions.create.path, {
        method: api.submissions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create submission");
      return api.submissions.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.submissions.list.path] });
      toast({ title: "Success", description: "Submission created successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

export function useUpdateSubmissionStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const url = buildUrl(api.submissions.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.submissions.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed to update status");
      return api.submissions.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.submissions.list.path] });
      toast({ title: "Success", description: "Status updated" });
    },
  });
}

export function useUpdateSubmissionDlv() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const url = buildUrl(api.submissions.updateDlv.path, { id });
      const res = await fetch(url, {
        method: api.submissions.updateDlv.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to submit DLV info");
      return api.submissions.updateDlv.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.submissions.list.path] });
      toast({ title: "Success", description: "DLV info submitted & user notified" });
    },
  });
}

// ==========================================
// USERS & NOTIFICATIONS
// ==========================================

export function useUsers() {
  return useQuery({
    queryKey: [api.users.list.path],
    queryFn: async () => {
      const res = await fetch(api.users.list.path);
      if (!res.ok) throw new Error("Failed to fetch users");
      return api.users.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch(api.users.create.path, {
        method: api.users.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create user");
      return api.users.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      toast({ title: "Success", description: "User created successfully" });
    },
  });
}

export function useSendPaymentReminder() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { userId: number; totalDue: number }) => {
      const res = await fetch(api.notifications.sendPaymentReminder.path, {
        method: api.notifications.sendPaymentReminder.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to send reminder");
      return api.notifications.sendPaymentReminder.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      toast({ title: "Sent", description: "Payment reminder sent to WhatsApp" });
    },
  });
}

export function useSendCenterInfo() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { centerId: number; userIds: number[] }) => {
      const res = await fetch(api.notifications.sendCenterInfo.path, {
        method: api.notifications.sendCenterInfo.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to send center info");
      return api.notifications.sendCenterInfo.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      toast({ title: "Sent", description: "Center info sent to selected users" });
    },
  });
}
