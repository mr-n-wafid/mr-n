import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertSubmission, type InsertCenter, type Center, type InsertUser, type InsertCity } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

// --- Cities ---
export function useCities() {
  return useQuery({
    queryKey: [api.cities.list.path],
    queryFn: async () => {
      const res = await fetch(api.cities.list.path);
      if (!res.ok) throw new Error("Failed to fetch cities");
      return api.cities.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateCity() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: InsertCity) => {
      const res = await fetch(api.cities.create.path, {
        method: api.cities.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create city");
      return api.cities.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.cities.list.path] });
      toast({ title: "Success", description: "City created successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

// --- Centers ---
export function useCenters(cityId?: number) {
  return useQuery({
    queryKey: [api.centers.list.path, cityId],
    queryFn: async () => {
      const url = cityId 
        ? `${api.centers.list.path}?cityId=${cityId}`
        : api.centers.list.path;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch centers");
      return api.centers.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateCenter() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: InsertCenter) => {
      const res = await fetch(api.centers.create.path, {
        method: api.centers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create center");
      return api.centers.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.centers.list.path] });
      toast({ title: "Success", description: "Center created successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

// --- Submissions ---
export function useCreateSubmission() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: InsertSubmission) => {
      const res = await fetch(api.submissions.create.path, {
        method: api.submissions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ message: "Failed to create submission" }));
        throw new Error(errorData.message || "Failed to create submission");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.submissions.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] });
      toast({ title: "Success", description: "Application submitted successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useSubmissions() {
  return useQuery({
    queryKey: [api.submissions.list.path],
    queryFn: async () => {
      const res = await fetch(api.submissions.list.path);
      if (!res.ok) throw new Error("Failed to fetch submissions");
      return api.submissions.list.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateSubmissionStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const url = buildUrl(api.submissions.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.submissions.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed to update status");
      return api.submissions.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.submissions.list.path] });
      toast({ title: "Success", description: "Status updated" });
    },
  });
}

export function useSubmitDlv() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: z.infer<typeof api.submissions.updateDlv.input> }) => {
      const url = buildUrl(api.submissions.updateDlv.path, { id });
      const res = await fetch(url, {
        method: api.submissions.updateDlv.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to submit DLV");
      return api.submissions.updateDlv.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.submissions.list.path] });
      toast({ title: "Success", description: "DLV sent to user" });
    },
  });
}

export function useUpdateCenter() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, ...data }: Partial<Center> & { id: number }) => {
      const url = buildUrl(api.centers.update.path, { id });
      const res = await fetch(url, {
        method: api.centers.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update center");
      return api.centers.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.centers.list.path] });
      toast({ title: "Success", description: "Center updated successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}
export function useUsers() {
  return useQuery({
    queryKey: [api.users.list.path],
    queryFn: async () => {
      const res = await fetch(api.users.list.path);
      if (!res.ok) throw new Error("Failed to fetch users");
      return api.users.list.responses[200].parse(await res.json());
    },
  });
}

export function useUsersWithStats() {
  return useQuery({
    queryKey: [api.users.listWithStats.path],
    queryFn: async () => {
      const res = await fetch(api.users.listWithStats.path);
      if (!res.ok) throw new Error("Failed to fetch users with stats");
      return api.users.listWithStats.responses[200].parse(await res.json());
    },
  });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.users.create.input>) => {
      const res = await fetch(api.users.create.path, {
        method: api.users.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ message: "Failed to create user" }));
        throw new Error(errorData.message || "Failed to create user");
      }
      return api.users.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.users.listWithStats.path] });
      toast({ title: "Success", description: "User created successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useUpdateWallet() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, amount }: { id: number; amount: number }) => {
      const url = buildUrl(api.users.updateWallet.path, { id });
      const res = await fetch(url, {
        method: api.users.updateWallet.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount }),
      });
      if (!res.ok) throw new Error("Failed to update wallet");
      return api.users.updateWallet.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.users.listWithStats.path] });
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] });
      queryClient.invalidateQueries({ queryKey: [api.payments.list.path] });
      toast({ title: "Success", description: "Wallet balance updated" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useDeleteUser() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.users.delete.path, { id });
      const res = await fetch(url, {
        method: api.users.delete.method,
      });
      if (!res.ok) throw new Error("Failed to delete user");
      return api.users.delete.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.users.listWithStats.path] });
      toast({ title: "Success", description: "User deleted successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useApplyWalletToDues() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (userId: number) => {
      const url = buildUrl(api.users.applyWalletToDues.path, { id: userId });
      const res = await fetch(url, {
        method: api.users.applyWalletToDues.method,
      });
      if (!res.ok) throw new Error("Failed to apply wallet");
      return api.users.applyWalletToDues.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.users.listWithStats.path] });
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] });
      queryClient.invalidateQueries({ queryKey: [api.payments.list.path] });
    },
  });
}

// --- WhatsApp Status ---
export function useWhatsAppStatus(enabled: boolean = true) {
  return useQuery({
    queryKey: ['/api/whatsapp/status'],
    queryFn: async () => {
      const res = await fetch(api.whatsapp.status.path);
      if (res.status === 401 || res.status === 403) {
        throw new Error("Unauthorized");
      }
      if (!res.ok) throw new Error("Failed to check status");
      return api.whatsapp.status.responses[200].parse(await res.json());
    },
    refetchInterval: enabled ? 60000 : false,
    enabled,
    retry: false,
  });
}

export function useWhatsAppTest() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (testNumber: string) => {
      const res = await fetch(api.whatsapp.test.path, {
        method: api.whatsapp.test.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ testNumber }),
      });
      if (!res.ok) throw new Error("Failed to send test");
      return api.whatsapp.test.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({ title: "Test Sent", description: "Check your WhatsApp for the test message" });
        queryClient.invalidateQueries({ queryKey: ['/api/whatsapp/status'] });
      } else {
        toast({ title: "Test Failed", description: data.message, variant: "destructive" });
      }
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

// --- Notifications ---
export function useSendPaymentReminder() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.notifications.sendPaymentReminder.input>) => {
      const res = await fetch(api.notifications.sendPaymentReminder.path, {
        method: api.notifications.sendPaymentReminder.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to send reminder");
      return api.notifications.sendPaymentReminder.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({ title: "Sent", description: data.message || "Payment reminder sent to WhatsApp" });
      } else {
        toast({ title: "Failed", description: data.message || "Failed to send reminder", variant: "destructive" });
      }
    },
  });
}

export function useSendCenterInfo() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { centerId: number; userIds: number[] }) => {
      // Stub implementation since the endpoint was removed
      console.log(`Sending Center Info to users: ${data.userIds.join(', ')} for center ${data.centerId}`);
      return { success: true };
    },
    onSuccess: () => {
      toast({ title: "Sent", description: "Center info forwarded to selected users" });
    },
  });
}

// --- Payments ---
export function usePayments() {
  return useQuery({
    queryKey: [api.payments.list.path],
    queryFn: async () => {
      const res = await fetch(api.payments.list.path);
      if (!res.ok) throw new Error("Failed to fetch payments");
      return await res.json();
    },
  });
}

export function useCreatePayment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { amount: number; paymentProof: string }) => {
      const res = await fetch(api.payments.create.path, {
        method: api.payments.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to submit payment");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payments.list.path] });
      toast({ title: "Success", description: "Payment proof submitted successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useUpdatePaymentStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const url = buildUrl(api.payments.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.payments.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed to update payment status");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payments.list.path] });
      toast({ title: "Success", description: "Payment status updated" });
    },
  });
}

// --- Update Requests ---
export function useUpdateRequests() {
  return useQuery({
    queryKey: [api.updateRequests.list.path],
    queryFn: async () => {
      const res = await fetch(api.updateRequests.list.path);
      if (!res.ok) throw new Error("Failed to fetch update requests");
      return await res.json();
    },
  });
}

export function useCreateUpdateRequest() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { userId: number; submissionId?: number; requestType: string; description: string }) => {
      const res = await fetch(api.updateRequests.create.path, {
        method: api.updateRequests.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create update request");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.updateRequests.list.path] });
      toast({ title: "Success", description: "Update request sent to user" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useRespondToUpdateRequest() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, responseFile }: { id: number; responseFile: string }) => {
      const url = buildUrl(api.updateRequests.respond.path, { id });
      const res = await fetch(url, {
        method: api.updateRequests.respond.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ responseFile }),
      });
      if (!res.ok) throw new Error("Failed to respond to update request");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.updateRequests.list.path] });
      toast({ title: "Success", description: "File uploaded successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}

export function useCompleteUpdateRequest() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.updateRequests.complete.path, { id });
      const res = await fetch(url, {
        method: api.updateRequests.complete.method,
      });
      if (!res.ok) throw new Error("Failed to complete update request");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.updateRequests.list.path] });
      toast({ title: "Success", description: "Update request marked as complete" });
    },
  });
}

// --- Push Notifications ---
export function useVapidPublicKey() {
  return useQuery({
    queryKey: [api.push.vapidPublicKey.path],
    queryFn: async () => {
      const res = await fetch(api.push.vapidPublicKey.path);
      if (!res.ok) throw new Error("Failed to fetch VAPID key");
      return api.push.vapidPublicKey.responses[200].parse(await res.json());
    },
  });
}

export function usePushSubscribe() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (subscription: string) => {
      const res = await fetch(api.push.subscribe.path, {
        method: api.push.subscribe.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subscription }),
      });
      if (!res.ok) throw new Error("Failed to save push subscription");
      return api.push.subscribe.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      toast({ title: "Notifications Enabled", description: "You'll receive notifications when your applications are processed." });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });
}
