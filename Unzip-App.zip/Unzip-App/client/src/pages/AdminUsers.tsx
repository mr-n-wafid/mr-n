import { useUsersWithStats, useCreateUser, useUpdateWallet, useSubmissions, useDeleteUser } from "@/hooks/use-gamca";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Loader2, Plus, Wallet, User, FileText, CheckCircle, Clock, Phone, Minus, Save, ChevronDown, MapPin, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";
import { api } from "@shared/routes";
import { format } from "date-fns";

const createUserFormSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  whatsappNumber: z.string().regex(/^\+?\d{10,15}$/, "Enter a valid WhatsApp number (10-15 digits)"),
  walletBalance: z.coerce.number().min(0, "Balance cannot be negative").default(0),
  role: z.enum(["user", "admin"]).default("user"),
});

type UserWithStats = z.infer<typeof api.users.listWithStats.responses[200]>[number];
type Submission = z.infer<typeof api.submissions.list.responses[200]>[number];

function UserProfileCard({ user, submissions }: { user: UserWithStats; submissions: Submission[] }) {
  const updateWallet = useUpdateWallet();
  const deleteUser = useDeleteUser();
  const [editOpen, setEditOpen] = useState(false);
  const [walletAmount, setWalletAmount] = useState(user.walletBalance);
  const [inputValue, setInputValue] = useState(String(user.walletBalance));
  const [historyOpen, setHistoryOpen] = useState(false);

  useEffect(() => {
    setWalletAmount(user.walletBalance);
    setInputValue(String(user.walletBalance));
  }, [user.walletBalance]);

  const handleDeleteUser = () => {
    deleteUser.mutate(user.id);
  };

  const handleSaveWallet = () => {
    const amount = Number(walletAmount);
    if (!Number.isFinite(amount) || amount < 0) {
      return;
    }
    updateWallet.mutate({ id: user.id, amount }, {
      onSuccess: () => setEditOpen(false)
    });
  };

  const adjustWallet = (delta: number) => {
    const newAmount = Math.max(0, walletAmount + delta);
    setWalletAmount(newAmount);
    setInputValue(String(newAmount));
  };

  const handleInputChange = (value: string) => {
    setInputValue(value);
    const num = parseInt(value, 10);
    if (Number.isFinite(num) && num >= 0) {
      setWalletAmount(num);
    }
  };

  return (
    <Card className="overflow-hidden border-none shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg" data-testid={`text-username-${user.id}`}>{user.username}</CardTitle>
              <CardDescription className="flex items-center gap-1">
                <Phone className="w-3 h-3" />
                <span data-testid={`text-whatsapp-${user.id}`}>{user.whatsappNumber || "No WhatsApp"}</span>
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={user.role === 'admin' ? 'default' : 'secondary'} className="capitalize">
              {user.role}
            </Badge>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  size="icon" 
                  variant="ghost" 
                  className="text-destructive"
                  data-testid={`button-delete-user-${user.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete User</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete {user.username}? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleDeleteUser}
                    className="bg-destructive text-destructive-foreground"
                  >
                    {deleteUser.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center gap-1 text-slate-500 text-xs mb-1">
              <FileText className="w-3 h-3" /> Total
            </div>
            <p className="text-xl font-bold text-slate-900 dark:text-slate-100" data-testid={`text-total-${user.id}`}>
              {user.totalSubmissions}
            </p>
          </div>
          <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center gap-1 text-green-600 text-xs mb-1">
              <CheckCircle className="w-3 h-3" /> Done
            </div>
            <p className="text-xl font-bold text-green-600" data-testid={`text-completed-${user.id}`}>
              {user.completedSubmissions}
            </p>
          </div>
          <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center gap-1 text-amber-600 text-xs mb-1">
              <Clock className="w-3 h-3" /> Pending
            </div>
            <p className="text-xl font-bold text-amber-600" data-testid={`text-pending-${user.id}`}>
              {user.pendingSubmissions}
            </p>
          </div>
        </div>

        {/* Wallet Section */}
        <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-blue-600" />
            <div>
              <p className="text-xs text-blue-600 font-medium">Wallet Balance</p>
              <p className="text-lg font-bold text-blue-700" data-testid={`text-balance-${user.id}`}>
                {user.walletBalance.toLocaleString()} BDT
              </p>
            </div>
          </div>
          
          <Dialog open={editOpen} onOpenChange={setEditOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                data-testid={`button-edit-wallet-${user.id}`}
                onClick={() => {
                  setWalletAmount(user.walletBalance);
                  setInputValue(String(user.walletBalance));
                }}
              >
                Edit Wallet
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Wallet: {user.username}</DialogTitle>
                <DialogDescription>
                  Adjust the wallet balance for this user
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6 py-4">
                <div className="text-center">
                  <p className="text-sm text-slate-500 mb-2">Current Balance</p>
                  <p className="text-3xl font-bold text-blue-600">{walletAmount.toLocaleString()} BDT</p>
                </div>
                
                <div className="space-y-3">
                  <p className="text-sm font-medium text-slate-700">Quick Adjust</p>
                  <div className="flex gap-2 flex-wrap">
                    <Button variant="outline" size="sm" onClick={() => adjustWallet(-500)}>
                      <Minus className="w-3 h-3 mr-1" /> 500
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => adjustWallet(-1000)}>
                      <Minus className="w-3 h-3 mr-1" /> 1000
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => adjustWallet(500)}>
                      <Plus className="w-3 h-3 mr-1" /> 500
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => adjustWallet(1000)}>
                      <Plus className="w-3 h-3 mr-1" /> 1000
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <p className="text-sm font-medium text-slate-700">Or set exact amount</p>
                  <Input
                    type="number"
                    min="0"
                    value={inputValue}
                    onChange={(e) => handleInputChange(e.target.value)}
                    data-testid={`input-wallet-amount-${user.id}`}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleSaveWallet} 
                  disabled={updateWallet.isPending}
                  data-testid={`button-save-wallet-${user.id}`}
                >
                  {updateWallet.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-1" /> Save Changes
                    </>
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Submission History */}
        <Collapsible open={historyOpen} onOpenChange={setHistoryOpen}>
          <CollapsibleTrigger asChild>
            <Button 
              variant="ghost" 
              className="w-full justify-between text-slate-600 dark:text-slate-400"
              data-testid={`button-toggle-history-${user.id}`}
            >
              <span className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Submission History ({submissions.length})
              </span>
              <ChevronDown className={`w-4 h-4 transition-transform ${historyOpen ? 'rotate-180' : ''}`} />
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent className="mt-2">
            {submissions.length === 0 ? (
              <p className="text-center text-sm text-slate-500 py-4">No submissions yet</p>
            ) : (
              <div className="max-h-64 overflow-y-auto space-y-2">
                {submissions.map((sub) => (
                  <div 
                    key={sub.id} 
                    className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg text-sm"
                    data-testid={`card-submission-${sub.id}`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-medium text-slate-900 dark:text-slate-100">{sub.center?.name || 'Unknown Center'}</span>
                      <Badge 
                        variant={sub.status === 'Done' ? 'default' : sub.status === 'DLV_Submitted' ? 'secondary' : 'outline'}
                      >
                        {sub.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <MapPin className="w-3 h-3" />
                      <span>{sub.city?.name || 'Unknown City'}</span>
                      <span className="mx-1">-</span>
                      <Badge variant="outline" className="text-xs py-0">
                        {sub.deliveryType}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between mt-2 text-xs text-slate-500">
                      <span>{sub.appliedPrice.toLocaleString()} BDT</span>
                      {sub.createdAt && (
                        <span>{format(new Date(sub.createdAt), 'MMM d, yyyy')}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}

export default function AdminUsers() {
  const { data: users, isLoading } = useUsersWithStats();
  const { data: allSubmissions } = useSubmissions();
  const createUser = useCreateUser();
  const [open, setOpen] = useState(false);

  const getUserSubmissions = (userId: number) => {
    return allSubmissions?.filter(s => s.userId === userId) || [];
  };

  const form = useForm<z.infer<typeof createUserFormSchema>>({
    resolver: zodResolver(createUserFormSchema),
    defaultValues: {
      username: "",
      password: "",
      whatsappNumber: "",
      walletBalance: 0,
      role: "user",
    },
  });

  const onSubmit = (data: z.infer<typeof createUserFormSchema>) => {
    createUser.mutate(data, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-gray-900 dark:text-gray-100">Wallet Control</h1>
          <p className="text-gray-500 mt-1">Manage user accounts, wallet balances, and view submission statistics</p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" data-testid="button-add-user">
              <Plus className="w-4 h-4" /> Add User
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create New User</DialogTitle>
              <DialogDescription>
                Add a new user account with initial wallet balance
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          placeholder="Enter username"
                          data-testid="input-new-username"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          {...field} 
                          placeholder="Min 6 characters"
                          data-testid="input-new-password"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="whatsappNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>WhatsApp Number</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          placeholder="+8801XXXXXXXXX"
                          data-testid="input-new-whatsapp"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="walletBalance"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Initial Wallet Balance (BDT)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          placeholder="0"
                          data-testid="input-new-balance"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role</FormLabel>
                      <FormControl>
                        <select 
                          {...field} 
                          className="w-full p-2 border rounded-md bg-background"
                          data-testid="select-new-role"
                        >
                          <option value="user">User</option>
                          <option value="admin">Admin</option>
                        </select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter className="pt-4">
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={createUser.isPending}
                    data-testid="button-submit-new-user"
                  >
                    {createUser.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      "Create User"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-md bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Total Users</p>
                <p className="text-3xl font-bold" data-testid="text-total-users">{users?.length || 0}</p>
              </div>
              <User className="w-10 h-10 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Total Wallet Balance</p>
                <p className="text-3xl font-bold" data-testid="text-total-balance">
                  {(users?.reduce((sum, u) => sum + u.walletBalance, 0) || 0).toLocaleString()} BDT
                </p>
              </div>
              <Wallet className="w-10 h-10 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Total Submissions</p>
                <p className="text-3xl font-bold" data-testid="text-total-submissions">
                  {users?.reduce((sum, u) => sum + u.totalSubmissions, 0) || 0}
                </p>
              </div>
              <FileText className="w-10 h-10 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* User Cards Grid */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
        </div>
      ) : users?.length === 0 ? (
        <Card className="p-12 text-center border-dashed">
          <User className="w-12 h-12 mx-auto text-slate-400 mb-4" />
          <p className="text-slate-500">No users found. Add your first user to get started.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {users?.map((user) => (
            <UserProfileCard key={user.id} user={user} submissions={getUserSubmissions(user.id)} />
          ))}
        </div>
      )}
    </div>
  );
}
