import {
  useSubmissions,
  useUpdateSubmissionStatus,
  useSubmitDlv,
  useCities,
} from "@/hooks/use-gamca";
import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import {
  FileText,
  Link as LinkIcon,
  Download,
  Filter,
  Copy,
  X,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Admin() {
  const { data: submissions } = useSubmissions();
  const { data: cities } = useCities();
  const updateStatus = useUpdateSubmissionStatus();
  const submitDlv = useSubmitDlv();

  const [dlvOpen, setDlvOpen] = useState(false);
  const [selectedSubId, setSelectedSubId] = useState<number | null>(null);
  const [filterCityId, setFilterCityId] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { toast } = useToast();

  const filteredSubmissions = submissions?.filter((sub) => {
    const cityMatch =
      filterCityId === "all" || sub.cityId.toString() === filterCityId;
    let statusMatch = false;
    if (statusFilter === "all") {
      statusMatch = true;
    } else if (statusFilter === "Done") {
      statusMatch = sub.status === "Done" || sub.status === "DLV_Submitted";
    } else {
      statusMatch = sub.status === statusFilter;
    }
    return cityMatch && statusMatch;
  });

  const handleReject = (id: number) => {
    updateStatus.mutate(
      { id, status: "Rejected" },
      {
        onSuccess: () => {
          toast({
            title: "Submission Rejected",
            description: "The submission has been marked as rejected",
          });
        },
      },
    );
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Link copied to clipboard",
    });
  };

  const dlvForm = useForm({
    defaultValues: {
      dlvName: "",
      dlvPassportNumber: "",
      dlvLink: "",
      dlvPrice: 0,
    },
  });

  const onDlvSubmit = (data: any) => {
    if (selectedSubId) {
      submitDlv.mutate(
        { id: selectedSubId, data },
        {
          onSuccess: () => {
            setDlvOpen(false);
            dlvForm.reset();
          },
        },
      );
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900 dark:text-slate-100">
          Admin Dashboard
        </h1>
        <p className="text-slate-500 dark:text-slate-400">
          Manage submission inbox
        </p>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader className="space-y-4">
          <div className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle>Submission Inbox</CardTitle>
              <CardDescription>Manage all user applications</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <Select value={filterCityId} onValueChange={setFilterCityId}>
                <SelectTrigger className="w-[180px] h-9">
                  <SelectValue placeholder="Filter by City" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {cities?.map((city) => (
                    <SelectItem key={city.id} value={city.id.toString()}>
                      {city.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Tabs
            value={statusFilter}
            onValueChange={setStatusFilter}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all" data-testid="tab-all">
                All ({submissions?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="Pending" data-testid="tab-pending">
                Pending (
                {submissions?.filter((s) => s.status === "Pending").length || 0}
                )
              </TabsTrigger>
              <TabsTrigger value="Done" data-testid="tab-done">
                Done (
                {submissions?.filter(
                  (s) => s.status === "Done" || s.status === "DLV_Submitted",
                ).length || 0}
                )
              </TabsTrigger>
              <TabsTrigger value="Rejected" data-testid="tab-rejected">
                Rejected (
                {submissions?.filter((s) => s.status === "Rejected").length ||
                  0}
                )
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Center</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Passport</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSubmissions?.map((sub) => (
                <TableRow key={sub.id}>
                  <TableCell className="font-medium">
                    {sub.user.username}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span>{sub.center.name}</span>
                      <span className="text-xs text-slate-500">
                        {sub.city.name}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        sub.deliveryType === "emergency"
                          ? "destructive"
                          : "secondary"
                      }
                    >
                      {sub.deliveryType}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {sub.passportLink ? (
                      <div className="flex items-center gap-2">
                        <a
                          href={sub.passportLink}
                          target="_blank"
                          className="text-blue-600 hover:underline flex items-center"
                        >
                          <LinkIcon className="w-3 h-3 mr-1" /> Link
                        </a>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-slate-400 hover:text-blue-600"
                          onClick={() => copyToClipboard(sub.passportLink!)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="text-slate-600 flex items-center">
                          <FileText className="w-3 h-3 mr-1" />{" "}
                          {sub.passportFile?.split("::")[0]}
                        </span>
                        {sub.passportFile && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-slate-400 hover:text-blue-600"
                            onClick={() => {
                              window.open(
                                `/api/submissions/${sub.id}/download`,
                                "_blank",
                              );
                            }}
                          >
                            <Download className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge
                      className={
                        sub.status === "Done" || sub.status === "DLV_Submitted"
                          ? "bg-green-500"
                          : sub.status === "Rejected"
                            ? "bg-red-500"
                            : "bg-amber-400"
                      }
                    >
                      {sub.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      {sub.status === "Pending" && (
                        <>
                          <Button
                            size="sm"
                            onClick={() =>
                              updateStatus.mutate({
                                id: sub.id,
                                status: "Done",
                              })
                            }
                            data-testid={`button-mark-done-${sub.id}`}
                          >
                            Mark Done
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                size="sm"
                                variant="destructive"
                                data-testid={`button-reject-${sub.id}`}
                              >
                                <X className="w-3 h-3 mr-1" /> Reject
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>
                                  Reject Submission?
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will mark the submission as rejected. The
                                  user will see this as rejected and will not be
                                  charged for this submission.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleReject(sub.id)}
                                >
                                  Reject
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </>
                      )}
                      {sub.status === "Done" && (
                        <Dialog
                          open={dlvOpen && selectedSubId === sub.id}
                          onOpenChange={(open) => {
                            setDlvOpen(open);
                            if (open) setSelectedSubId(sub.id);
                            else setSelectedSubId(null);
                          }}
                        >
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="default"
                              className="bg-purple-600 hover:bg-purple-700"
                            >
                              DLV
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Submit DLV Result</DialogTitle>
                            </DialogHeader>
                            <form
                              onSubmit={dlvForm.handleSubmit(onDlvSubmit)}
                              className="space-y-4 py-4"
                            >
                              <div className="space-y-2">
                                <Label>Name</Label>
                                <Input
                                  {...dlvForm.register("dlvName", {
                                    required: true,
                                  })}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Passport Number</Label>
                                <Input
                                  {...dlvForm.register("dlvPassportNumber", {
                                    required: true,
                                  })}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Result Link</Label>
                                <Input
                                  {...dlvForm.register("dlvLink", {
                                    required: true,
                                  })}
                                />
                              </div>
                              <DialogFooter>
                                <Button
                                  type="submit"
                                  disabled={submitDlv.isPending}
                                >
                                  {submitDlv.isPending
                                    ? "Sending..."
                                    : "Submit & Notify User"}
                                </Button>
                              </DialogFooter>
                            </form>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
