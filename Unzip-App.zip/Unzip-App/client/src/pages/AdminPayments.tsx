import { useUsers, useSubmissions, usePayments, useUpdatePaymentStatus, useSendPaymentReminder, useApplyWalletToDues } from "@/hooks/use-gamca";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, DollarSign, Camera, CheckCircle, Download, FileText, XCircle, Clock, MessageCircle } from "lucide-react";
import { format } from "date-fns";
import { useEffect, useRef } from "react";

export default function AdminPayments() {
  const { data: users, isLoading: loadingUsers } = useUsers();
  const { data: submissions, isLoading: loadingSubmissions } = useSubmissions();
  const { data: payments, isLoading: loadingPayments } = usePayments();
  const updatePaymentStatus = useUpdatePaymentStatus();
  const sendReminder = useSendPaymentReminder();
  const applyWallet = useApplyWalletToDues();
  const walletsApplied = useRef(false);

  // Apply wallet deductions for all users when admin loads the page
  useEffect(() => {
    if (!walletsApplied.current && !loadingUsers && !loadingSubmissions && !loadingPayments && users) {
      walletsApplied.current = true;
      users.filter(u => u.role !== 'admin').forEach(user => {
        applyWallet.mutate(user.id);
      });
    }
  }, [loadingUsers, loadingSubmissions, loadingPayments, users]);

  const getUserDue = (userId: number) => {
    const totalSubmissions = submissions
      ?.filter(s => s.userId === userId && (s.status === 'Done' || s.status === 'DLV_Submitted'))
      .reduce((sum, s) => sum + s.appliedPrice + (s.dlvPrice || 0), 0) || 0;
    
    const approvedPayments = payments
      ?.filter((p: any) => p.userId === userId && p.status === 'approved')
      .reduce((sum: number, p: any) => sum + p.amount, 0) || 0;
    
    return Math.max(0, totalSubmissions - approvedPayments);
  };

  const totalSystemDue = users?.filter(u => u.role !== 'admin')
    .reduce((sum, u) => sum + Math.max(0, getUserDue(u.id)), 0) || 0;

  const handleSendReminder = (userId: number, totalDue: number) => {
    sendReminder.mutate({ userId, totalDue });
  };

  const handleDownload = (paymentId: number) => {
    window.open(`/api/payments/${paymentId}/download`, '_blank');
  };

  const pendingPayments = payments?.filter((p: any) => p.status === 'pending') || [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved': return <Badge variant="default" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">Approved</Badge>;
      case 'rejected': return <Badge variant="destructive">Rejected</Badge>;
      default: return <Badge variant="secondary">Pending</Badge>;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-gray-900 dark:text-gray-100">Payment Management</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Track user dues and verify payments</p>
        </div>
        
        <Card className="bg-gradient-to-r from-blue-600 to-blue-700 dark:from-blue-700 dark:to-blue-800 text-white border-none shadow-lg">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-xl">
                <DollarSign className="w-6 h-6" />
              </div>
              <div>
                <p className="text-blue-100 text-sm font-medium">Total System Due</p>
                <h3 className="text-2xl font-bold text-white" data-testid="text-total-system-due">{totalSystemDue.toLocaleString()} BDT</h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-none shadow-xl shadow-blue-500/5">
          <CardHeader>
            <CardTitle>User Dues</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/50 dark:bg-gray-800/50">
                  <TableHead>User</TableHead>
                  <TableHead>WhatsApp</TableHead>
                  <TableHead className="text-right">Total Due</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingUsers ? (
                   <TableRow>
                     <TableCell colSpan={4} className="text-center py-12">
                       <Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-500"/>
                     </TableCell>
                   </TableRow>
                ) : users?.filter(u => u.role !== 'admin').map((user) => {
                  const due = getUserDue(user.id);
                  return (
                    <TableRow key={user.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-800/50">
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell className="text-gray-500 dark:text-gray-400">{user.whatsappNumber}</TableCell>
                      <TableCell className={`text-right font-bold ${due > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {due.toLocaleString()} BDT
                      </TableCell>
                      <TableCell className="text-right">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="text-green-600 border-green-200"
                          onClick={() => handleSendReminder(user.id, due)}
                          disabled={sendReminder.isPending || !user.whatsappNumber || due <= 0}
                          data-testid={`button-send-reminder-${user.id}`}
                        >
                          <MessageCircle className="w-4 h-4 mr-2" />
                          {sendReminder.isPending ? "Sending..." : "Send Reminder"}
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="border-none shadow-xl shadow-blue-500/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5 text-blue-600" />
              Payment Proofs ({pendingPayments.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loadingPayments ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
                </div>
              ) : pendingPayments.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 border-2 border-dashed rounded-xl bg-slate-50/50 dark:bg-slate-800/50 dark:border-slate-700">
                   <CheckCircle className="w-12 h-12 text-slate-300 dark:text-slate-600 mb-4" />
                   <p className="text-slate-400 dark:text-slate-500 font-medium">No pending proofs</p>
                   <p className="text-xs text-slate-400 dark:text-slate-500">All payments are verified</p>
                </div>
              ) : (
                pendingPayments.map((payment: any) => (
                  <div key={payment.id} className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg space-y-3" data-testid={`payment-proof-${payment.id}`}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{payment.user?.username || 'Unknown'}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {payment.createdAt ? format(new Date(payment.createdAt), 'MMM dd, yyyy • hh:mm a') : '-'}
                        </p>
                      </div>
                      <span className="font-bold text-blue-600">{payment.amount.toLocaleString()} BDT</span>
                    </div>
                    
                    {payment.paymentProof && (
                      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                        <FileText className="w-4 h-4" />
                        <span className="truncate flex-1">{payment.paymentProof.split("::")[0]}</span>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => handleDownload(payment.id)}
                        >
                          <Download className="w-4 h-4 text-blue-600" />
                        </Button>
                      </div>
                    )}
                    
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        className="flex-1 bg-green-600 hover:bg-green-700"
                        onClick={() => updatePaymentStatus.mutate({ id: payment.id, status: 'approved' })}
                        disabled={updatePaymentStatus.isPending}
                        data-testid={`button-approve-${payment.id}`}
                      >
                        <CheckCircle className="w-4 h-4 mr-1" /> Approve
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        className="flex-1"
                        onClick={() => updatePaymentStatus.mutate({ id: payment.id, status: 'rejected' })}
                        disabled={updatePaymentStatus.isPending}
                        data-testid={`button-reject-${payment.id}`}
                      >
                        <XCircle className="w-4 h-4 mr-1" /> Reject
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {payments && payments.filter((p: any) => p.status !== 'pending').length > 0 && (
        <Card className="border-none shadow-md">
          <CardHeader>
            <CardTitle>Payment History</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/50 dark:bg-gray-800/50">
                  <TableHead>User</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Proof</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.filter((p: any) => p.status !== 'pending').map((payment: any) => (
                  <TableRow key={payment.id}>
                    <TableCell className="font-medium">{payment.user?.username || 'Unknown'}</TableCell>
                    <TableCell>{payment.amount.toLocaleString()} BDT</TableCell>
                    <TableCell className="text-slate-500">
                      {payment.createdAt ? format(new Date(payment.createdAt), 'MMM dd, yyyy') : '-'}
                    </TableCell>
                    <TableCell>{getStatusBadge(payment.status)}</TableCell>
                    <TableCell className="text-right">
                      {payment.paymentProof && (
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => handleDownload(payment.id)}
                        >
                          <Download className="w-4 h-4 text-blue-600" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
