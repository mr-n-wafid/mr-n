import { useCities, useCenters, useUpdateCenter } from "@/hooks/use-gamca";
import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Building2, Search, Save, Loader2, Plus, Minus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminNeedFile() {
  const { data: cities, isLoading: loadingCities } = useCities();
  const [selectedCityId, setSelectedCityId] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [editingQuantities, setEditingQuantities] = useState<Record<number, number>>({});
  const { toast } = useToast();
  
  const cityIdForQuery = selectedCityId === "all" ? undefined : Number(selectedCityId);
  const { data: centers, isLoading: loadingCenters } = useCenters(cityIdForQuery);
  const updateCenter = useUpdateCenter();

  const filteredCenters = useMemo(() => {
    if (!centers) return [];
    if (!searchQuery.trim()) return centers;
    return centers.filter(center => 
      center.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [centers, searchQuery]);

  const getCityName = (cityId: number) => {
    return cities?.find(c => c.id === cityId)?.name || "Unknown";
  };

  const getQuantityValue = (centerId: number, currentQuantity: number) => {
    return editingQuantities[centerId] !== undefined ? editingQuantities[centerId] : currentQuantity;
  };

  const handleQuantityChange = (centerId: number, value: number) => {
    setEditingQuantities(prev => ({ ...prev, [centerId]: Math.max(0, value) }));
  };

  const handleSave = (centerId: number) => {
    const newQuantity = editingQuantities[centerId];
    if (newQuantity === undefined) return;
    
    updateCenter.mutate({
      id: centerId,
      neededQuantity: newQuantity
    }, {
      onSuccess: () => {
        setEditingQuantities(prev => {
          const updated = { ...prev };
          delete updated[centerId];
          return updated;
        });
        toast({ title: "Updated", description: "Quantity updated successfully" });
      }
    });
  };

  const incrementQuantity = (centerId: number, currentQuantity: number) => {
    const current = getQuantityValue(centerId, currentQuantity);
    handleQuantityChange(centerId, current + 1);
  };

  const decrementQuantity = (centerId: number, currentQuantity: number) => {
    const current = getQuantityValue(centerId, currentQuantity);
    handleQuantityChange(centerId, current - 1);
  };

  const isModified = (centerId: number, currentQuantity: number) => {
    return editingQuantities[centerId] !== undefined && editingQuantities[centerId] !== currentQuantity;
  };

  if (loadingCities) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900 dark:text-slate-100">Update Need File</h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Set the quantity of files needed for each medical center</p>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-primary" /> Medical Centers
          </CardTitle>
          <CardDescription>Adjust the needed quantity for each center</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input 
                placeholder="Search centers..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-centers"
              />
            </div>
            <Select value={selectedCityId} onValueChange={setSelectedCityId}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Filter by City" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cities</SelectItem>
                {cities?.map(city => (
                  <SelectItem key={city.id} value={city.id.toString()}>{city.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {loadingCenters ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : filteredCenters.length === 0 ? (
            <div className="text-center py-12 text-slate-500 dark:text-slate-400">
              No centers found
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Center Name</TableHead>
                  <TableHead>City</TableHead>
                  <TableHead className="text-center">Current Need</TableHead>
                  <TableHead className="text-center">Quantity</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCenters.map(center => (
                  <TableRow key={center.id} data-testid={`center-row-${center.id}`}>
                    <TableCell className="font-medium">{center.name}</TableCell>
                    <TableCell className="text-slate-500 dark:text-slate-400">{getCityName(center.cityId)}</TableCell>
                    <TableCell className="text-center">
                      <Badge 
                        variant={center.neededQuantity > 0 ? "default" : "secondary"}
                        className={center.neededQuantity > 0 ? "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300" : ""}
                      >
                        {center.neededQuantity}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-2">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => decrementQuantity(center.id, center.neededQuantity)}
                          data-testid={`button-decrement-${center.id}`}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <Input 
                          type="number" 
                          className="w-20 text-center" 
                          value={getQuantityValue(center.id, center.neededQuantity)}
                          onChange={(e) => handleQuantityChange(center.id, parseInt(e.target.value) || 0)}
                          data-testid={`input-quantity-${center.id}`}
                        />
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => incrementQuantity(center.id, center.neededQuantity)}
                          data-testid={`button-increment-${center.id}`}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        size="sm"
                        disabled={!isModified(center.id, center.neededQuantity) || updateCenter.isPending}
                        onClick={() => handleSave(center.id)}
                        data-testid={`button-save-${center.id}`}
                      >
                        {updateCenter.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <Save className="w-4 h-4 mr-1" /> Save
                          </>
                        )}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
