import { useSubmissions, useCreatePayment, usePayments, useApplyWalletToDues } from "@/hooks/use-gamca";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Upload, Wallet, CreditCard, FileText, Loader2, CheckCircle, Clock, XCircle } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function Payment() {
  const { user } = useAuth();
  const { data: submissions, isLoading: loadingSubmissions } = useSubmissions();
  const { data: payments, isLoading: loadingPayments } = usePayments();
  const createPayment = useCreatePayment();
  const applyWallet = useApplyWalletToDues();
  const walletApplied = useRef(false);

  const [amount, setAmount] = useState("");
  const [proofFile, setProofFile] = useState<string | null>(null);
  const [proofFileName, setProofFileName] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const { toast } = useToast();

  const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

  // Automatically apply wallet to dues when page loads
  useEffect(() => {
    if (user?.id && !walletApplied.current && !loadingSubmissions && !loadingPayments) {
      walletApplied.current = true;
      applyWallet.mutate(user.id);
    }
  }, [user?.id, loadingSubmissions, loadingPayments]);

  // Only count Done and DLV_Submitted submissions for dues (not Rejected or Pending)
  const totalDue = submissions?.filter(sub => sub.status === 'Done' || sub.status === 'DLV_Submitted')
    .reduce((sum, sub) => sum + sub.appliedPrice + (sub.dlvPrice || 0), 0) || 0;
  const approvedPayments = payments?.filter((p: any) => p.status === 'approved').reduce((sum: number, p: any) => sum + p.amount, 0) || 0;
  const walletBalance = user?.walletBalance || 0;
  const remainingDue = Math.max(0, totalDue - approvedPayments);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadError(null);
      
      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        setUploadError(`File is too large. Maximum size is 10MB. Your file is ${(file.size / 1024 / 1024).toFixed(2)}MB`);
        toast({
          title: "File too large",
          description: `Maximum file size is 10MB. Your file is ${(file.size / 1024 / 1024).toFixed(2)}MB`,
          variant: "destructive",
        });
        e.target.value = '';
        return;
      }

      // Validate file type
      const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
      if (!validTypes.includes(file.type)) {
        setUploadError("Invalid file type. Please upload JPG, PNG, or PDF files only.");
        toast({
          title: "Invalid file type",
          description: "Please upload JPG, PNG, or PDF files only.",
          variant: "destructive",
        });
        e.target.value = '';
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setProofFile(`${file.name}::${base64String}`);
        setProofFileName(file.name);
        toast({
          title: "File uploaded",
          description: `${file.name} uploaded successfully`,
        });
      };
      reader.onerror = () => {
        setUploadError("Failed to read file. Please try again.");
        toast({
          title: "Upload failed",
          description: "Failed to read file. Please try again.",
          variant: "destructive",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!amount || !proofFile) return;
    
    createPayment.mutate({
      amount: Number(amount),
      paymentProof: proofFile,
    }, {
      onSuccess: () => {
        setAmount("");
        setProofFile(null);
        setProofFileName(null);
      }
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'rejected': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-amber-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved': return <Badge variant="default" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">Approved</Badge>;
      case 'rejected': return <Badge variant="destructive">Rejected</Badge>;
      default: return <Badge variant="secondary">Pending</Badge>;
    }
  };

  if (loadingSubmissions || loadingPayments) return <Loader2 className="w-8 h-8 animate-spin mx-auto mt-20" />;

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
         <h1 className="text-3xl font-display font-bold text-slate-900 dark:text-slate-100">Payments</h1>
         <p className="text-slate-500 dark:text-slate-400">Manage your dues and upload payment proof</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="bg-gradient-to-br from-slate-900 to-slate-800 text-white border-none shadow-xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Wallet className="w-5 h-5 text-blue-400" /> Total Outstanding Due
            </CardTitle>
          </CardHeader>
          <CardContent>
             <div className={`font-bold font-display tracking-tight text-blue-400 mb-2 ${
               remainingDue >= 100000 ? 'text-3xl' : remainingDue >= 10000 ? 'text-4xl' : 'text-5xl'
             }`}>
               {remainingDue.toLocaleString()} <span className="text-2xl text-slate-400 font-normal">BDT</span>
             </div>
             <p className="text-sm text-slate-400">Total: {totalDue.toLocaleString()} BDT | Paid: {approvedPayments.toLocaleString()} BDT</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
               <CreditCard className="w-5 h-5 text-primary" /> Payment Methods
            </CardTitle>
            <CardDescription>Send payment to these accounts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="p-4 bg-pink-50 dark:bg-pink-900/20 rounded-xl border border-pink-100 dark:border-pink-800">
               <p className="text-xs text-pink-600 dark:text-pink-400 font-bold uppercase tracking-wider mb-1">Bkash Personal</p>
               <p className="text-xl font-mono font-bold text-slate-900 dark:text-slate-100">01700-000000</p>
             </div>
             <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800">
               <p className="text-xs text-blue-600 dark:text-blue-400 font-bold uppercase tracking-wider mb-1">Bank Transfer (City Bank)</p>
               <p className="font-semibold text-slate-900 dark:text-slate-100">Gamca Care Ltd.</p>
               <p className="font-mono text-slate-600 dark:text-slate-400">Ac: 1234567890</p>
               <p className="text-sm text-slate-500 dark:text-slate-400">Branch: Gulshan 1</p>
             </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle>Submit Payment Proof</CardTitle>
          <CardDescription>Upload a screenshot of your transaction</CardDescription>
        </CardHeader>
        <CardContent>
           <div className="space-y-4">
              <div className="grid w-full max-w-sm items-center gap-1.5">
                <Label htmlFor="amount">Amount Paid (BDT)</Label>
                <Input 
                  type="number" 
                  id="amount" 
                  placeholder="5000" 
                  className="rounded-xl"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  data-testid="input-payment-amount"
                />
              </div>
              
              <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-8 text-center hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer">
                 <Input 
                   type="file" 
                   className="hidden" 
                   id="proof-upload"
                   accept=".jpg,.jpeg,.png,.pdf"
                   onChange={handleFileUpload}
                 />
                 <label htmlFor="proof-upload" className="cursor-pointer block">
                    <Upload className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">Upload Transaction Screenshot</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">JPG, PNG, or PDF up to 10MB</p>
                    {uploadError && (
                      <p className="text-xs text-red-500 mt-2">{uploadError}</p>
                    )}
                    {proofFileName && (
                      <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-full text-xs font-medium">
                        <FileText className="w-3 h-3" /> {proofFileName}
                      </div>
                    )}
                 </label>
              </div>

              <Button 
                className="btn-primary w-full md:w-auto"
                onClick={handleSubmit}
                disabled={!amount || !proofFile || createPayment.isPending}
                data-testid="button-submit-payment"
              >
                {createPayment.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Submit Payment Proof
              </Button>
           </div>
        </CardContent>
      </Card>

      {payments && payments.length > 0 && (
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Payment History</CardTitle>
            <CardDescription>Your submitted payment proofs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {payments.map((payment: any) => (
                <div key={payment.id} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg" data-testid={`payment-item-${payment.id}`}>
                  <div className="flex items-center gap-3">
                    {getStatusIcon(payment.status)}
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-slate-100">{payment.amount.toLocaleString()} BDT</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {payment.createdAt ? format(new Date(payment.createdAt), 'MMM dd, yyyy • hh:mm a') : '-'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {payment.paymentProof && (
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        <FileText className="w-4 h-4 inline mr-1" />
                        {payment.paymentProof.split("::")[0]}
                      </span>
                    )}
                    {getStatusBadge(payment.status)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
