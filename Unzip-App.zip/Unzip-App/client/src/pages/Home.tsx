import { useAuth } from "@/hooks/use-auth";
import { useCities, useCenters, useCreateSubmission } from "@/hooks/use-gamca";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSubmissionSchema } from "@shared/schema";
import { z } from "zod";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Upload, Link as LinkIcon, AlertCircle, FileText, CheckCircle } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

// Extend schema for form validation
const formSchema = insertSubmissionSchema.extend({
  cityId: z.coerce.number().min(1, "City is required"),
  centerId: z.coerce.number().min(1, "Center is required"),
  appliedPrice: z.coerce.number(),
  deliveryType: z.enum(["none", "emergency"]),
  passportFile: z.string().optional(),
  passportLink: z.string().optional(),
}).refine(data => data.passportFile || data.passportLink, {
  message: "Either a file or link is required",
  path: ["passportFile"], 
});

export default function Home() {
  const { user } = useAuth();
  const { data: cities, isLoading: loadingCities } = useCities();
  
  const [selectedCity, setSelectedCity] = useState<number | null>(null);
  const { data: centers, isLoading: loadingCenters } = useCenters(selectedCity || undefined);
  
  const createSubmission = useCreateSubmission();
  const { toast } = useToast();
  const [uploadError, setUploadError] = useState<string | null>(null);

  const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      deliveryType: "none",
      appliedPrice: 0,
    }
  });

  const selectedCenterId = form.watch("centerId");
  const deliveryType = form.watch("deliveryType");
  const selectedCenter = centers?.find(c => c.id === selectedCenterId);

  // Update price when center or delivery type changes
  const currentPrice = selectedCenter 
    ? (deliveryType === "emergency" ? selectedCenter.emergencyPrice : selectedCenter.normalPrice)
    : 0;

  // Helper to sanitize names for filenames (remove special chars, replace spaces with underscores)
  const sanitizeForFilename = (name: string) => {
    return name.replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, '_').trim() || 'unknown';
  };

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    // Generate proper filename if file was uploaded
    let finalPassportFile = data.passportFile;
    if (data.passportFile && data.passportFile.includes('::')) {
      const [extension, base64Data] = data.passportFile.split('::');
      const username = sanitizeForFilename(user?.username || 'user');
      const centerName = sanitizeForFilename(selectedCenter?.name || 'center');
      const newFilename = `${username}_${centerName}.${extension}`;
      finalPassportFile = `${newFilename}::${base64Data}`;
    }

    const submissionData = {
      cityId: data.cityId,
      centerId: data.centerId,
      deliveryType: data.deliveryType,
      passportFile: finalPassportFile,
      passportLink: data.passportLink,
      appliedPrice: currentPrice,
    };

    createSubmission.mutate(submissionData, {
      onSuccess: () => {
        form.reset();
        setSelectedCity(null);
      }
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">New Application</h1>
          <p className="text-slate-500 mt-1">Submit a new medical center application</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="border-none shadow-lg">
            <CardHeader className="bg-slate-50 border-b border-slate-100 rounded-t-xl">
              <CardTitle>Application Details</CardTitle>
              <CardDescription>Fill in the required information below</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                
                {/* Location Selection */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>City</Label>
                    <Select 
                      onValueChange={(val) => {
                        const id = Number(val);
                        setSelectedCity(id);
                        form.setValue("cityId", id);
                        form.setValue("centerId", 0); // Reset center
                      }}
                      disabled={loadingCities}
                    >
                      <SelectTrigger className="h-12 rounded-xl">
                        <SelectValue placeholder="Select City" />
                      </SelectTrigger>
                      <SelectContent>
                        {cities?.map(city => (
                          <SelectItem key={city.id} value={city.id.toString()}>{city.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Medical Center</Label>
                    <Select 
                      onValueChange={(val) => form.setValue("centerId", Number(val))}
                      disabled={!selectedCity || loadingCenters}
                    >
                      <SelectTrigger className="h-12 rounded-xl">
                        <SelectValue placeholder={loadingCenters ? "Loading..." : "Select Center"} />
                      </SelectTrigger>
                      <SelectContent>
                        {centers?.map(center => (
                          <SelectItem key={center.id} value={center.id.toString()}>{center.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Delivery Type */}
                <div className="space-y-3">
                  <Label>Delivery Priority</Label>
                  <RadioGroup 
                    defaultValue="none" 
                    onValueChange={(val) => form.setValue("deliveryType", val as "none" | "emergency")}
                    className="grid grid-cols-1 md:grid-cols-2 gap-4"
                  >
                    <div className={`
                      flex items-center space-x-3 border-2 rounded-xl p-4 cursor-pointer transition-all
                      ${deliveryType === "none" ? "border-primary bg-primary/5" : "border-slate-200 hover:border-slate-300"}
                    `}>
                      <RadioGroupItem value="none" id="normal" />
                      <Label htmlFor="normal" className="flex-1 cursor-pointer">
                        <div className="font-semibold text-slate-900">Normal Delivery</div>
                        <div className="text-sm text-slate-500">Standard processing time</div>
                      </Label>
                    </div>

                    <div className={`
                      flex items-center space-x-3 border-2 rounded-xl p-4 cursor-pointer transition-all
                      ${deliveryType === "emergency" ? "border-accent bg-accent/5" : "border-slate-200 hover:border-slate-300"}
                    `}>
                      <RadioGroupItem value="emergency" id="emergency" />
                      <Label htmlFor="emergency" className="flex-1 cursor-pointer">
                        <div className="font-semibold text-slate-900">Emergency</div>
                        <div className="text-sm text-slate-500">Urgent processing (Extra charge)</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Passport Upload / Link */}
                <div className="space-y-2">
                  <Label>Passport Document</Label>
                  <Tabs defaultValue="upload" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 mb-4 h-12 bg-slate-100 p-1 rounded-xl">
                      <TabsTrigger value="upload" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
                        <Upload className="w-4 h-4 mr-2" /> Upload File
                      </TabsTrigger>
                      <TabsTrigger value="link" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
                        <LinkIcon className="w-4 h-4 mr-2" /> Direct Link
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="upload">
                      <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center hover:bg-slate-50 transition-colors cursor-pointer">
                        <Input 
                          type="file" 
                          accept=".jpg,.jpeg,.png,.pdf"
                          className="hidden" 
                          id="file-upload"
                          data-testid="input-passport-file"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              setUploadError(null);
                              
                              // Validate file size
                              if (file.size > MAX_FILE_SIZE) {
                                setUploadError(`File is too large. Maximum size is 10MB. Your file is ${(file.size / 1024 / 1024).toFixed(2)}MB`);
                                toast({
                                  title: "File too large",
                                  description: `Maximum file size is 10MB. Your file is ${(file.size / 1024 / 1024).toFixed(2)}MB`,
                                  variant: "destructive",
                                });
                                e.target.value = '';
                                return;
                              }

                              // Validate file type
                              const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
                              if (!validTypes.includes(file.type)) {
                                setUploadError("Invalid file type. Please upload JPG, PNG, or PDF files only.");
                                toast({
                                  title: "Invalid file type",
                                  description: "Please upload JPG, PNG, or PDF files only.",
                                  variant: "destructive",
                                });
                                e.target.value = '';
                                return;
                              }

                              const reader = new FileReader();
                              reader.onloadend = () => {
                                const base64String = reader.result as string;
                                // Store file with original extension (filename will be generated on submit)
                                const extension = file.name.split('.').pop()?.toLowerCase() || 'jpg';
                                form.setValue("passportFile", `${extension}::${base64String}`);
                                toast({
                                  title: "File uploaded",
                                  description: `${file.name} uploaded successfully`,
                                });
                              };
                              reader.onerror = () => {
                                setUploadError("Failed to read file. Please try again.");
                                toast({
                                  title: "Upload failed",
                                  description: "Failed to read file. Please try again.",
                                  variant: "destructive",
                                });
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                        <label htmlFor="file-upload" className="cursor-pointer">
                          <Upload className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                          <p className="text-sm font-medium text-slate-900">Click to upload passport</p>
                          <p className="text-xs text-slate-500 mt-1">PDF, JPG, PNG up to 10MB</p>
                          {uploadError && (
                            <p className="text-xs text-red-500 mt-2">{uploadError}</p>
                          )}
                          {form.watch("passportFile") && (
                            <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                              <FileText className="w-3 h-3" /> File uploaded (.{form.watch("passportFile")?.split("::")[0]})
                            </div>
                          )}
                        </label>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="link">
                      <Input 
                        placeholder="Paste Google Drive / Dropbox link here..." 
                        className="h-12 rounded-xl"
                        {...form.register("passportLink")}
                      />
                    </TabsContent>
                  </Tabs>
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  className="w-full h-14 text-lg font-semibold btn-primary"
                  disabled={createSubmission.isPending}
                >
                  {createSubmission.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin mr-2" />
                  ) : "Submit Application"}
                </Button>

              </form>
            </CardContent>
          </Card>
        </div>

        {/* Summary Card */}
        <div>
          <Card className="border-none shadow-lg bg-slate-900 text-white sticky top-8">
            <CardHeader>
              <CardTitle className="text-white">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center py-2 border-b border-white/10">
                <span className="text-slate-400">Center</span>
                <span className="font-medium text-right max-w-[50%] truncate">
                  {selectedCenter?.name || "-"}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-white/10">
                <span className="text-slate-400">Type</span>
                <span className="font-medium capitalize">{deliveryType === "none" ? "Normal" : "Emergency"}</span>
              </div>
              <div className="pt-4">
                <div className="flex justify-between items-end">
                  <span className="text-slate-400">Total Price</span>
                  <span className="text-3xl font-bold font-display text-blue-400">
                    {currentPrice > 0 ? `${currentPrice} BDT` : "-"}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  * Final price includes all processing fees
                </p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4 mt-6 flex gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 shrink-0" />
                <p className="text-xs text-slate-300 leading-relaxed">
                  Please ensure passport details are clear. Incorrect information may lead to rejection.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
