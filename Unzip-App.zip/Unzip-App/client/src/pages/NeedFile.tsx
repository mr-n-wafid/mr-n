import { useCities, useCenters } from "@/hooks/use-gamca";
import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Building2, Search, FileText, ChevronRight, ArrowLeft, Loader2 } from "lucide-react";

export default function NeedFile() {
  const { data: cities, isLoading: loadingCities } = useCities();
  const [selectedCityId, setSelectedCityId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: centers, isLoading: loadingCenters } = useCenters(selectedCityId || undefined);

  const selectedCity = cities?.find(c => c.id === selectedCityId);

  const filteredCenters = useMemo(() => {
    if (!centers) return [];
    if (!searchQuery.trim()) return centers;
    return centers.filter(center => 
      center.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [centers, searchQuery]);

  const centersWithNeed = filteredCenters.filter(c => c.neededQuantity > 0);

  if (loadingCities) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 dark:text-slate-100">Need File</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            {selectedCity 
              ? `Medical centers in ${selectedCity.name} requiring files`
              : "Select a city to view file requirements"
            }
          </p>
        </div>
        {selectedCityId && (
          <Button 
            variant="outline" 
            onClick={() => {
              setSelectedCityId(null);
              setSearchQuery("");
            }}
            data-testid="button-back-cities"
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Cities
          </Button>
        )}
      </div>

      {!selectedCityId ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {cities?.map(city => {
            return (
              <Card 
                key={city.id} 
                className="border-none shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer group"
                onClick={() => setSelectedCityId(city.id)}
                data-testid={`city-card-${city.id}`}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                        <MapPin className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg text-slate-900 dark:text-slate-100">{city.name}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">View medical centers</p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-blue-600 transition-colors" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="space-y-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Search medical centers..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search-centers"
            />
          </div>

          {loadingCenters ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : centersWithNeed.length === 0 ? (
            <Card className="border-none shadow-md">
              <CardContent className="py-12 text-center">
                <FileText className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                <p className="text-slate-500 dark:text-slate-400 font-medium">No files needed at this time</p>
                <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">
                  {searchQuery ? "Try a different search term" : "All requirements are fulfilled for this city"}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {centersWithNeed.map(center => (
                <Card key={center.id} className="border-none shadow-md" data-testid={`center-card-${center.id}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-xl">
                          <Building2 className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900 dark:text-slate-100">{center.name}</h3>
                          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{selectedCity?.name}</p>
                        </div>
                      </div>
                      <Badge variant="default" className="bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300 text-lg px-3 py-1">
                        {center.neededQuantity}
                      </Badge>
                    </div>
                    <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        <span className="font-medium text-amber-600 dark:text-amber-400">{center.neededQuantity}</span> file{center.neededQuantity !== 1 ? 's' : ''} needed
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
