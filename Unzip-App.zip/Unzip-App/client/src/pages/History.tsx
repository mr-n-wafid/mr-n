import { useSubmissions, useCities, useCenters } from "@/hooks/use-gamca";
import { useState } from "react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Link as LinkIcon, Download, Loader2, Filter, X, Trash2, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function History() {
  const { data: submissions, isLoading } = useSubmissions();
  const { data: cities } = useCities();
  const { data: centers } = useCenters();
  const { toast } = useToast();
  
  const [cityFilter, setCityFilter] = useState<string>("all");
  const [centerFilter, setCenterFilter] = useState<string>("all");

  const handleCopyResult = (sub: typeof submissions extends (infer T)[] | undefined ? T : never) => {
    const text = `Name: ${sub.dlvName || 'N/A'}
Passport Number: ${sub.dlvPassportNumber || 'N/A'}
Link: ${sub.dlvLink || 'N/A'}
Center: ${sub.center?.name || 'N/A'}`;
    
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: "Copied!", description: "Result details copied to clipboard" });
    }).catch(() => {
      toast({ title: "Error", description: "Failed to copy", variant: "destructive" });
    });
  };

  const filteredSubmissions = submissions?.filter(sub => {
    if (cityFilter !== "all" && sub.cityId !== Number(cityFilter)) return false;
    if (centerFilter !== "all" && sub.centerId !== Number(centerFilter)) return false;
    return true;
  });

  const clearFilters = () => {
    setCityFilter("all");
    setCenterFilter("all");
  };

  const hasFilters = cityFilter !== "all" || centerFilter !== "all";

  const handleDownload = async (submissionId: number) => {
    try {
      const response = await fetch(`/api/submissions/${submissionId}/download`);
      if (!response.ok) throw new Error("Download failed");
      
      const contentDisposition = response.headers.get('Content-Disposition');
      const fileName = contentDisposition?.match(/filename="(.+)"/)?.[1] || 'download';
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error("Download error:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 dark:text-slate-100">Application History</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Track your previous medical applications</p>
        </div>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="w-5 h-5" /> Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-slate-600 dark:text-slate-400">City</label>
              <Select value={cityFilter} onValueChange={setCityFilter}>
                <SelectTrigger data-testid="select-city-filter">
                  <SelectValue placeholder="All Cities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {cities?.map(city => (
                    <SelectItem key={city.id} value={city.id.toString()}>{city.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-slate-600 dark:text-slate-400">Medical Center</label>
              <Select value={centerFilter} onValueChange={setCenterFilter}>
                <SelectTrigger data-testid="select-center-filter">
                  <SelectValue placeholder="All Centers" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Centers</SelectItem>
                  {centers?.map(center => (
                    <SelectItem key={center.id} value={center.id.toString()}>{center.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {hasFilters && (
              <Button variant="outline" onClick={clearFilters} className="gap-2" data-testid="button-clear-filters">
                <X className="w-4 h-4" /> Clear Filters
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between items-center">
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Showing {filteredSubmissions?.length || 0} of {submissions?.length || 0} submissions
        </p>
      </div>

      <div className="grid gap-4">
        {filteredSubmissions?.length === 0 ? (
          <Card className="p-8 text-center text-slate-500 border-dashed">
            {hasFilters ? "No submissions match your filters." : "No submissions found. Start a new application!"}
          </Card>
        ) : (
          filteredSubmissions?.map((sub) => (
            <Card key={sub.id} className="overflow-hidden border-none shadow-md hover:shadow-lg transition-all duration-200" data-testid={`card-submission-${sub.id}`}>
              <div className="flex flex-col md:flex-row md:items-center">
                <div className={`
                  h-2 md:h-auto md:w-2 self-stretch
                  ${sub.status === 'Done' || sub.status === 'DLV_Submitted' ? 'bg-green-500' : 'bg-amber-400'}
                `} />
                
                <div className="p-6 flex-1 grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                  <div className="md:col-span-1">
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wider mb-1">
                      {sub.city?.name || "Unknown City"}
                    </p>
                    <h3 className="font-bold text-slate-900 dark:text-slate-100">{sub.center?.name || "Unknown Center"}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                      {sub.createdAt ? format(new Date(sub.createdAt), 'MMM dd, yyyy • hh:mm a') : '-'}
                    </p>
                  </div>

                  <div className="md:col-span-1">
                    <Badge variant={sub.deliveryType === 'emergency' ? 'destructive' : 'secondary'} className="mb-2">
                      {sub.deliveryType === 'emergency' ? 'Emergency' : 'Normal'}
                    </Badge>
                    <p className="font-semibold text-slate-900 dark:text-slate-100">{sub.appliedPrice} BDT</p>
                  </div>

                  <div className="md:col-span-1">
                     <div className="flex items-center gap-2 text-sm">
                        {sub.passportLink ? (
                          <a href={sub.passportLink} target="_blank" rel="noreferrer" className="flex items-center text-blue-600 hover:underline">
                            <LinkIcon className="w-4 h-4 mr-1" /> View Link
                          </a>
                        ) : sub.passportFile ? (
                          <div className="flex items-center gap-2">
                            <span className="flex items-center text-slate-600 dark:text-slate-400">
                              <FileText className="w-4 h-4 mr-1" /> {sub.passportFile.split("::")[0]}
                            </span>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8"
                              onClick={() => handleDownload(sub.id)}
                              data-testid={`button-download-${sub.id}`}
                            >
                              <Download className="w-4 h-4 text-blue-600" />
                            </Button>
                          </div>
                        ) : (
                          <span className="text-slate-400">No file</span>
                        )}
                     </div>
                  </div>

                  <div className="md:col-span-1 text-right">
                    <Badge variant={sub.status === 'Done' || sub.status === 'DLV_Submitted' ? 'default' : 'outline'} className={`
                      px-3 py-1 text-sm font-semibold
                      ${sub.status === 'Done' || sub.status === 'DLV_Submitted' ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300'}
                    `}>
                      {sub.status === 'DLV_Submitted' ? 'Completed' : sub.status}
                    </Badge>

                    {sub.status === 'DLV_Submitted' && (
                      <div className="mt-3 text-xs text-right space-y-1 bg-slate-50 dark:bg-slate-800 p-2 rounded-lg border border-slate-100 dark:border-slate-700">
                        <p className="font-semibold text-slate-900 dark:text-slate-100">Result Available</p>
                        <p className="text-slate-600 dark:text-slate-400">Passport: {sub.dlvPassportNumber}</p>
                        <button 
                          onClick={() => handleCopyResult(sub)}
                          className="text-blue-600 hover:text-blue-700 flex items-center justify-end gap-1 ml-auto"
                          data-testid={`button-copy-result-${sub.id}`}
                        >
                          Copy Result <Copy className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
