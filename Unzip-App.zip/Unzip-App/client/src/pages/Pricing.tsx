import { useAuth } from "@/hooks/use-auth";
import { useCenters, useCities, useUsers, useSendCenterInfo, useUpdateCenter, useCreateCenter, useCreateCity } from "@/hooks/use-gamca";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Send, Building2, Loader2, Edit2, Plus, Search } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";

export default function Pricing() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  
  const { data: cities } = useCities();
  const [selectedCity, setSelectedCity] = useState<number | undefined>(undefined);
  const { data: centers, isLoading } = useCenters(selectedCity);
  
  const updateCenter = useUpdateCenter();
  const createCenter = useCreateCenter();
  const createCity = useCreateCity();

  // Admin Forward Logic
  const { data: users } = useUsers();
  const [selectedCenterForForward, setSelectedCenterForForward] = useState<number | null>(null);
  const [selectedUsersToForward, setSelectedUsersToForward] = useState<number[]>([]);
  const sendCenterInfo = useSendCenterInfo();

  const handleForward = () => {
    if (selectedCenterForForward && selectedUsersToForward.length > 0) {
      sendCenterInfo.mutate({
        centerId: selectedCenterForForward,
        userIds: selectedUsersToForward
      }, {
        onSuccess: () => {
          setSelectedCenterForForward(null);
          setSelectedUsersToForward([]);
        }
      });
    }
  };

  const [editCenterId, setEditCenterId] = useState<number | null>(null);
  const editForm = useForm();
  
  const onEditSubmit = (data: any) => {
    if (editCenterId) {
      updateCenter.mutate({ 
        id: editCenterId, 
        normalPrice: Number(data.normalPrice), 
        emergencyPrice: Number(data.emergencyPrice) 
      }, {
        onSuccess: () => setEditCenterId(null)
      });
    }
  };

  const [addCenterOpen, setAddCenterOpen] = useState(false);
  const addCenterForm = useForm();
  const onAddCenterSubmit = (data: any) => {
    createCenter.mutate({
      name: data.name,
      cityId: Number(data.cityId),
      normalPrice: Number(data.normalPrice),
      emergencyPrice: Number(data.emergencyPrice)
    }, {
      onSuccess: () => {
        setAddCenterOpen(false);
        addCenterForm.reset();
      }
    });
  };

  const [addCityOpen, setAddCityOpen] = useState(false);
  const [newCityName, setNewCityName] = useState("");
  const onAddCity = () => {
    if (newCityName) {
      createCity.mutate({ name: newCityName }, {
        onSuccess: () => {
          setAddCityOpen(false);
          setNewCityName("");
        }
      });
    }
  };

  const [searchQuery, setSearchQuery] = useState("");

  const filteredCenters = centers?.filter(center => 
    center.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cities?.find(c => c.id === center.cityId)?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 dark:text-slate-100">Centers & Rates</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Current pricing for all medical centers</p>
        </div>
        
        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          {isAdmin && (
            <div className="flex gap-2">
               <Dialog open={addCityOpen} onOpenChange={setAddCityOpen}>
                 <DialogTrigger asChild><Button variant="outline" size="sm"><Plus className="w-4 h-4 mr-1"/> City</Button></DialogTrigger>
                 <DialogContent>
                   <DialogHeader><DialogTitle>Add New City</DialogTitle></DialogHeader>
                   <div className="space-y-4 py-4">
                     <div className="space-y-2">
                       <Label>City Name</Label>
                       <Input value={newCityName} onChange={(e) => setNewCityName(e.target.value)} placeholder="e.g. Dhaka" />
                     </div>
                   </div>
                   <DialogFooter><Button onClick={onAddCity} disabled={createCity.isPending}>Add City</Button></DialogFooter>
                 </DialogContent>
               </Dialog>

               <Dialog open={addCenterOpen} onOpenChange={setAddCenterOpen}>
                 <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1"/> Center</Button></DialogTrigger>
                 <DialogContent>
                   <DialogHeader><DialogTitle>Add New Center</DialogTitle></DialogHeader>
                   <form onSubmit={addCenterForm.handleSubmit(onAddCenterSubmit)} className="space-y-4 py-4">
                     <div className="space-y-2">
                       <Label>Center Name</Label>
                       <Input {...addCenterForm.register("name", { required: true })} />
                     </div>
                     <div className="space-y-2">
                       <Label>City</Label>
                       <Select onValueChange={(v) => addCenterForm.setValue("cityId", v)}>
                         <SelectTrigger><SelectValue placeholder="Select City" /></SelectTrigger>
                         <SelectContent>
                           {cities?.map(c => <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>)}
                         </SelectContent>
                       </Select>
                     </div>
                     <div className="space-y-2">
                       <Label>Normal Price (BDT)</Label>
                       <Input type="number" {...addCenterForm.register("normalPrice", { required: true })} />
                     </div>
                     <div className="space-y-2">
                       <Label>Emergency Price (BDT)</Label>
                       <Input type="number" {...addCenterForm.register("emergencyPrice", { required: true })} />
                     </div>
                     <DialogFooter><Button type="submit" disabled={createCenter.isPending}>Add Center</Button></DialogFooter>
                   </form>
                 </DialogContent>
               </Dialog>
            </div>
          )}
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Search centers..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white dark:bg-slate-800"
              data-testid="input-search-centers"
            />
          </div>
          <div className="w-full md:w-48">
             <Select onValueChange={(val) => setSelectedCity(val === "all" ? undefined : Number(val))}>
              <SelectTrigger className="bg-white dark:bg-slate-800">
                <SelectValue placeholder="Filter by City" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cities</SelectItem>
                {cities?.map(c => (
                  <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                ))}
              </SelectContent>
             </Select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          <div className="col-span-full flex justify-center py-12">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : filteredCenters?.length === 0 ? (
          <div className="col-span-full text-center py-12 text-slate-500">
            No centers found matching "{searchQuery}"
          </div>
        ) : (
          filteredCenters?.map(center => (
            <Card key={center.id} className="border-none shadow-md hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                   <div className="p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                     <Building2 className="w-6 h-6" />
                   </div>
                   <div className="flex gap-2">
                     {isAdmin && (
                       <>
                        <Dialog open={editCenterId === center.id} onOpenChange={(o) => setEditCenterId(o ? center.id : null)}>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-slate-600">
                              <Edit2 className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader><DialogTitle>Edit Prices: {center.name}</DialogTitle></DialogHeader>
                            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4 py-4">
                              <div className="space-y-2">
                                <Label>Normal Price (BDT)</Label>
                                <Input type="number" defaultValue={center.normalPrice} {...editForm.register("normalPrice", { required: true })} />
                              </div>
                              <div className="space-y-2">
                                <Label>Emergency Price (BDT)</Label>
                                <Input type="number" defaultValue={center.emergencyPrice} {...editForm.register("emergencyPrice", { required: true })} />
                              </div>
                              <DialogFooter><Button type="submit" disabled={updateCenter.isPending}>Update Prices</Button></DialogFooter>
                            </form>
                          </DialogContent>
                        </Dialog>

                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="outline" size="sm" 
                              onClick={() => setSelectedCenterForForward(center.id)}
                              className="text-xs h-8"
                            >
                              <Send className="w-3 h-3 mr-1" /> Forward
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-md">
                            <DialogHeader>
                              <DialogTitle>Forward {center.name}</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4 py-4">
                              <Label>Select Users to Notify</Label>
                              <ScrollArea className="h-[300px] border rounded-md p-4">
                                 {users?.map(u => (
                                   <div key={u.id} className="flex items-center space-x-2 py-2 border-b last:border-0">
                                     <Checkbox 
                                       id={`user-${u.id}`} 
                                       checked={selectedUsersToForward.includes(u.id)}
                                       onCheckedChange={(checked) => {
                                         if (checked) setSelectedUsersToForward([...selectedUsersToForward, u.id]);
                                         else setSelectedUsersToForward(selectedUsersToForward.filter(id => id !== u.id));
                                       }}
                                     />
                                     <label htmlFor={`user-${u.id}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex-1">
                                       {u.username} <span className="text-xs text-slate-400">({u.role})</span>
                                     </label>
                                   </div>
                                 ))}
                              </ScrollArea>
                            </div>
                            <DialogFooter>
                               <Button onClick={handleForward} disabled={sendCenterInfo.isPending || selectedUsersToForward.length === 0}>
                                 {sendCenterInfo.isPending ? "Sending..." : "Send via WhatsApp"}
                               </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                       </>
                     )}
                   </div>
                </div>
                <CardTitle className="mt-4 text-xl">{center.name}</CardTitle>
                <p className="text-sm text-slate-500 font-medium">
                  {cities?.find(c => c.id === center.cityId)?.name}
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 pt-2">
                  <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                    <span className="text-sm font-medium text-slate-600">Normal</span>
                    <span className="font-bold text-slate-900">{center.normalPrice} BDT</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <span className="text-sm font-medium text-red-600">Emergency</span>
                    <span className="font-bold text-red-700">{center.emergencyPrice} BDT</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
