import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/Layout";
import { useAuth, AuthProvider } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

import NotFound from "@/pages/not-found";
import Login from "@/pages/Login";
import Home from "@/pages/Home";
import History from "@/pages/History";
import Admin from "@/pages/Admin";
import AdminUsers from "@/pages/AdminUsers";
import AdminPayments from "@/pages/AdminPayments";
import AdminNeedFile from "@/pages/AdminNeedFile";
import Pricing from "@/pages/Pricing";
import Payment from "@/pages/Payment";
import NeedFile from "@/pages/NeedFile";

function ProtectedRoute({ component: Component, adminOnly = false }: { component: React.ComponentType, adminOnly?: boolean }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    );
  }

  if (!user) {
    setTimeout(() => setLocation("/login"), 0);
    return null;
  }

  if (adminOnly && user.role !== 'admin') {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-8">
         <h2 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h2>
         <p className="text-slate-500">You do not have permission to view this page.</p>
      </div>
    );
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      {/* Protected Routes */}
      <Route path="/">
        <Layout><ProtectedRoute component={Home} /></Layout>
      </Route>
      
      <Route path="/history">
        <Layout><ProtectedRoute component={History} /></Layout>
      </Route>

      <Route path="/pricing">
        <Layout><ProtectedRoute component={Pricing} /></Layout>
      </Route>

      <Route path="/payment">
        <Layout><ProtectedRoute component={Payment} /></Layout>
      </Route>

      <Route path="/need-file">
        <Layout><ProtectedRoute component={NeedFile} /></Layout>
      </Route>

      {/* Admin Routes - Separate pages for each admin section */}
      <Route path="/admin/need-file">
        <Layout><ProtectedRoute component={AdminNeedFile} adminOnly /></Layout>
      </Route>

      <Route path="/admin/users">
        <Layout><ProtectedRoute component={AdminUsers} adminOnly /></Layout>
      </Route>
      
      <Route path="/admin/payments">
        <Layout><ProtectedRoute component={AdminPayments} adminOnly /></Layout>
      </Route>
      
      <Route path="/admin">
        <Layout><ProtectedRoute component={Admin} adminOnly /></Layout>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <Router />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
