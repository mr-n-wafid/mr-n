## Packages
framer-motion | Smooth animations for page transitions and interactions
lucide-react | Beautiful icons for the interface
date-fns | formatting dates
clsx | class name utility
tailwind-merge | merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
